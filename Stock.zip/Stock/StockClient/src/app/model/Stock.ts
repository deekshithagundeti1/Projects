
export class Stock{
    public id:number;
    constructor(
            public stockname:String,
            public ceo:String,
            public description:String,
            public ipodate:String
        ) {
    }  
}