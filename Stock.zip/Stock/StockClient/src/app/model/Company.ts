
export class Company{
    public id:number;
    constructor(
            public companyname:String,
            public ceo:String,
            public turnover:String,
            public description:String,
            public ipodate:String
        ) {
    }  
}