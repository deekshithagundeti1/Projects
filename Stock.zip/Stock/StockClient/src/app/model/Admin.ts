
export class Admin{
    constructor(
            public username:String,
            public password:String
        ) {
    }  
}