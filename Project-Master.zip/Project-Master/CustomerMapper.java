package com.cts.Customer.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.cts.Customer.Model.Customer;
import com.cts.Customer.Model.CustomerReference;
//Class to map Customer and Customer Reference
public class CustomerMapper implements RowMapper<CustomerReference> {

	@Override
	public CustomerReference mapRow(ResultSet rs, int rownum) throws SQLException {
		CustomerReference customerData = new CustomerReference();

		customerData.setReference_id(rs.getLong("reference_id"));
		customerData.setReference_name(rs.getString("reference_name"));
		customerData.setCustomer_id(rs.getLong("customer_id"));
		customerData.setCustomer(customerListMapper(rs));

		return customerData;
	}

	public List<Customer> customerListMapper(ResultSet rs) throws SQLException {
		List<Customer> customerList = new ArrayList<Customer>();
		do {
			customerList.add(new Customer(rs.getLong("customer_id"), rs.getString("customer_name"),
					rs.getLong("created_user_id"), rs.getTimestamp("created_dttm"), rs.getLong("updated_user_id"),
					rs.getTimestamp("updated_dttm"), rs.getInt("status")));
		} while (rs.next());

		return customerList;
	}

}
