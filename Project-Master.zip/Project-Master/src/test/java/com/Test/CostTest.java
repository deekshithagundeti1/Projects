package com.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.model.Cost;
import com.service.CostService;

public class CostTest {

	private static CostService mockedService;
	private static Cost cost1;
	private static Cost cost2;
	private static Cost cost3;
	private static long project_id=1;
	static Timestamp timestamp = new Timestamp(System.currentTimeMillis());

	@BeforeClass
	public static void Setup() throws Exception {

		mockedService = mock(CostService.class);

		cost1 = new Cost(1, 1234, 76876, 345, timestamp, 765768, timestamp, true);

		cost2 = new Cost(2, 987, 732465, 565, timestamp, 754353, timestamp, false);

		cost3 = new Cost(3, 456, 34535, 466, timestamp, 754333, timestamp, true);

		// Stubbing the methods of mocked CustomerService with mocked data.
		when(mockedService.getCostForAllProjects()).thenReturn(Arrays.asList(cost1,cost2,cost3));
		when(mockedService.getCostById((long) 1)).thenReturn(cost1);
		when(mockedService.getCostByProjectId(project_id)).thenReturn(cost1);
		when(mockedService.addCost(cost1)).thenReturn(cost1.getCost_master_id());
		when(mockedService.updateCost(cost1)).thenReturn(true);
		when(mockedService.deleteCost((long) 3)).thenReturn(true);
		when(mockedService.activateCost((long) 2)).thenReturn(true);
		when(mockedService.deactivateCost((long) 1)).thenReturn(true);

	}

	// To test whether the cost is added
	@Test
	public void testAddCost() throws Exception {
		long id = mockedService.addCost(cost1);
		Cost cost = mockedService.getCostById(id);
		assertNotNull(id);
		assertNotNull(cost);
		assertEquals(1, cost.getCost_master_id());
		assertEquals(1234, cost.getProject_id());
		assertEquals(76876, cost.getLocation_id());
		assertEquals(345, cost.getCreated_user_id());
		assertEquals(timestamp, cost.getCreated_dttm());
		assertEquals(765768, cost.getUpdated_user_id());
		assertEquals(timestamp, cost.getUpdated_dttm());
		assertEquals(true, cost.getStatus());

	}

	// To test whether the cost of particular id is fetched
	@Test
	public void testGetCostById() throws Exception {
		long cost_master_id = 1;
		Cost cost = mockedService.getCostById(cost_master_id);

		assertNotNull(cost);
		assertEquals(cost_master_id, cost.getCost_master_id());
		assertEquals(1234, cost.getProject_id());
		assertEquals(76876, cost.getLocation_id());
		assertEquals(345, cost.getCreated_user_id());
		assertEquals(timestamp, cost.getCreated_dttm());
		assertEquals(765768, cost.getUpdated_user_id());
		assertEquals(timestamp, cost.getUpdated_dttm());
		assertEquals(true, cost.getStatus());

	}

	// To test whether all the costs are fetched
	@Test
	public void testGetCostForAllProjects() throws Exception {

		List<Cost> costs = mockedService.getCostForAllProjects();
		assertEquals(3, costs.size());
		Cost cost = costs.get(0);
		assertEquals(1, cost.getCost_master_id());
		assertEquals(1234, cost.getProject_id());
		assertEquals(76876, cost.getLocation_id());
		assertEquals(345, cost.getCreated_user_id());
		assertEquals(timestamp, cost.getCreated_dttm());
		assertEquals(765768, cost.getUpdated_user_id());
		assertEquals(timestamp, cost.getUpdated_dttm());
		assertEquals(true, cost.getStatus());

	}

	// To test whether the cost of particular id is deleted
	@Test
	public void testDeleteCost() throws Exception {
		long cost_master_id = 3;
		boolean result = mockedService.deleteCost(cost_master_id);
		assertNotNull(result);
		assertEquals(true, result);
	}

	// To test whether the cost is updated
	@Test
	public void testUpdateCost() throws Exception {
		boolean result = mockedService.updateCost(cost1);
		assertNotNull(result);
		assertEquals(true, result);
	}

	//To test whether the Cost of particular id is activated
	@Test
	public void testActivateCost() throws Exception {
		long  cost_master_id = 2;
		boolean result = mockedService.activateCost( cost_master_id);
		assertNotNull(result);
		assertEquals(true, result);
	}

	//To test whether the Cost of particular id is deactivated
	@Test
	public void testDeactivateCost() throws Exception {
		long cost_master_id = 1;
		boolean result = mockedService.deactivateCost( cost_master_id);
		assertNotNull(result);
		assertEquals(true, result);
	}

	//To test whether the cost of particular project id is fetched
	@Test
	public void testGetCostByProjectId() throws Exception {

		Cost cost= mockedService.getCostByProjectId(project_id);
		assertNotNull(cost);
		assertEquals(1, cost.getCost_master_id());
		assertEquals(1234, cost.getProject_id());
		assertEquals(76876, cost.getLocation_id());
		assertEquals(345, cost.getCreated_user_id());
		assertEquals(timestamp, cost.getCreated_dttm());
		assertEquals(765768, cost.getUpdated_user_id());
		assertEquals(timestamp, cost.getUpdated_dttm());
		assertEquals(true, cost.getStatus());
	}





}
