package com.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.model.Customer;
import com.service.CustomerService;

@RunWith(MockitoJUnitRunner.class)
public class CustomerTest {
	
	 private static CustomerService mockedService;
	  private static Customer customer1;
	  private static Customer customer2;
	  private static Customer customer3;
	  static Timestamp timestamp= new Timestamp(System.currentTimeMillis());
	  
	  @BeforeClass
	  public static void Setup() throws Exception {
		  
		  mockedService = mock(CustomerService.class);
		 
		  customer1 = new Customer(123,"Will",768765,timestamp,765768,timestamp,true);

		    customer2 = new Customer(987,"John",732465,timestamp,754353,timestamp,false);
		    
		   customer3 = new Customer(456,"Carl",732466,timestamp,754333,timestamp,true);

		    //Stubbing the methods of mocked CustomerService with mocked data. 
		    when(mockedService.getAllCustomers()).thenReturn(Arrays.asList(customer1, customer2,customer3));
		    when(mockedService.getAllActiveCustomers()).thenReturn(Arrays.asList(customer1, customer3));
		    when(mockedService.getCustomerById((long) 123)).thenReturn(customer1);
		    when(mockedService.getCustomerByName("Carl")).thenReturn(customer3);
		    when(mockedService.addCustomer(customer1)).thenReturn(customer1.getCustomer_id());
		    when(mockedService.deleteCustomerById((long) 123)).thenReturn(true);
		    when(mockedService.activateCustomerById((long) 987)).thenReturn(true);
		    when(mockedService.deactivateCustomerById((long) 123)).thenReturn(true);
		    when(mockedService.updateCustomer(customer1)).thenReturn(true);

	  }
	  

	  //To test whether the customer is added
	@Test
	  public void testAddCustomer() throws Exception {
		  long id = mockedService.addCustomer(customer1);
		  Customer customer = mockedService.getCustomerById(id);
		    assertNotNull(id);
		    assertNotNull(customer);
		    assertEquals(123, customer.getCustomer_id());
		    assertEquals("Will", customer.getCustomer_name());
		    assertEquals(768765, customer.getCreated_user_id());
		    assertEquals( timestamp, customer.getCreated_dttm());
		    assertEquals(765768, customer.getUpdated_user_id());
		    assertEquals(timestamp, customer.getUpdated_dttm());
		    assertEquals(true, customer.getStatus());

	  }

	//To test whether the customer of particular id is fetched
	  @Test
	  public void testGetCustomerById() throws Exception {
		  long customer_id = 123;
		  Customer customer = mockedService.getCustomerById(customer_id);

		    assertNotNull(customer);
		    assertEquals(customer_id, customer.getCustomer_id());
		    assertEquals("Will", customer.getCustomer_name());
		    assertEquals(768765, customer.getCreated_user_id());
		    assertEquals(timestamp, customer.getCreated_dttm());
		    assertEquals(765768, customer.getUpdated_user_id());
		    assertEquals(timestamp, customer.getUpdated_dttm());
		    assertEquals(true, customer.getStatus());

	  }
	//To test whether the customer of particular name is fetched
	  @Test
	  public void testGetCustomerByName() throws Exception {
		  String customer_name = "Carl";
		  Customer customer = mockedService.getCustomerByName(customer_name);

		    assertNotNull(customer);
		    assertEquals(456, customer.getCustomer_id());
		    assertEquals("Carl", customer.getCustomer_name());
		    assertEquals(732466, customer.getCreated_user_id());
		    assertEquals(timestamp, customer.getCreated_dttm());
		    assertEquals(754333, customer.getUpdated_user_id());
		    assertEquals(timestamp, customer.getUpdated_dttm());
		    assertEquals(true, customer.getStatus());

	  }

	//To test whether all the customers are fetched
	  @Test
	  public void testGetAllCustomers() throws Exception {
		  
		  List<Customer> customers = mockedService.getAllCustomers();
		    assertEquals(3, customers.size());
		    Customer customer = customers.get(0);
		    assertEquals(123, customer.getCustomer_id());
		    assertEquals("Will", customer.getCustomer_name());
		    assertEquals(768765, customer.getCreated_user_id());
		    assertEquals(timestamp, customer.getCreated_dttm());
		    assertEquals(765768, customer.getUpdated_user_id());
		    assertEquals(timestamp, customer.getUpdated_dttm());
		    assertEquals(true, customer.getStatus());

	  }

	//To test whether all the active customers are fetched
	  @Test
	  public void testGetAllActiveCustomers() throws Exception {
		  
		  List<Customer> customers = mockedService.getAllActiveCustomers();
		    assertEquals(2, customers.size());
		    Customer customer = customers.get(0);
		    assertEquals(123, customer.getCustomer_id());
		    assertEquals("Will", customer.getCustomer_name());
		    assertEquals(768765, customer.getCreated_user_id());
		    assertEquals(timestamp, customer.getCreated_dttm());
		    assertEquals(765768, customer.getUpdated_user_id());
		    assertEquals(timestamp, customer.getUpdated_dttm());
		    assertEquals(true, customer.getStatus());

	  }
	  
	  //To test whether the customer of particular id is deleted
	  @Test
	  public void testDeleteCustomerById() throws Exception {
		  long customer_id = 123;
		  boolean result = mockedService.deleteCustomerById(customer_id);
		  	assertNotNull(result);
		  	assertEquals(true, result);
	  }
	  
	//To test whether the customer is updated
	  @Test
	  public void testUpdateCustomer() throws Exception {
		  boolean result = mockedService.updateCustomer(customer1);
		  	assertNotNull(result);
		  	assertEquals(true, result);
	  }
	  
	//To test whether the customer of particular id is activated
	  @Test
	  public void testActivateCustomerById() throws Exception {
		  long customer_id = 987;
		  boolean result = mockedService.activateCustomerById(customer_id);
		  	assertNotNull(result);
		  	assertEquals(true, result);
	  }
	  
	//To test whether the customer of particular id is deactivated
	  @Test
	  public void testDeactivateCustomerById() throws Exception {
		  long customer_id = 123;
		  boolean result = mockedService.deactivateCustomerById(customer_id);
		  	assertNotNull(result);
		  	assertEquals(true, result);
	  }


}
