package com.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.model.Employee;
import com.service.EmployeeService;

public class EmployeeTest {

	private static EmployeeService mockedService;
	private static Employee e1;
	private static Employee e2;
	private static Employee e3;

	static Timestamp timestamp= new Timestamp(System.currentTimeMillis());
	final static long project_id=1;
	@BeforeClass
	public static void Setup() throws Exception {

		mockedService = mock(EmployeeService.class);

		e1 = new Employee(1,"PrafullaChandra",30724,timestamp,1,timestamp,1,true);

		e2 = new Employee(2,"SreeKrishna",30978,timestamp,2,timestamp,2,false);

		e3 = new Employee(3,"Vedantam",30935,timestamp,3,timestamp,3,false);

		//Stubbing the methods of mocked CustomerService with mocked data. 
		when(mockedService.getAllEmployee()).thenReturn(Arrays.asList(e1,e2,e3));
		when(mockedService.getActiveEmployee()).thenReturn(Arrays.asList(e1));
		when(mockedService.getEmployeeById((long) 1)).thenReturn(e1);
		when(mockedService.getEmployeeByNameAndProjectId("PrafullaChandra",project_id)).thenReturn(e1);
		when(mockedService.addEmployee(e1)).thenReturn(e1.getEmployee_id());
		when(mockedService.UpdateEmployee(e1)).thenReturn(true);
		when(mockedService.deleteEmployee((long) 3)).thenReturn(true);
		when(mockedService.activateEmployee((long) 2)).thenReturn(true);
		when(mockedService.deactivateEmployee((long) 1)).thenReturn(true);


	}


	//To test whether the employee is added
	@Test
	public void testAddEmployee() throws Exception {
		long id = mockedService.addEmployee(e1);
		Employee employee = mockedService.getEmployeeById(id);
		assertNotNull(id);
		assertNotNull(employee);
		assertEquals(1, employee.getEmployee_id());
		assertEquals("PrafullaChandra", employee.getEmployee_name());
		assertEquals(30724, employee.getCreated_user_id());
		assertEquals( timestamp,employee.getCreated_dttm());
		assertEquals(1, employee.getUpdated_user_id());
		assertEquals(timestamp, employee.getUpdated_dttm());
		assertEquals(1, employee.getProject_id());
		assertEquals(true, employee.getStatus());

	}

	//To test whether the employee of particular id is fetched
	@Test
	public void testGetEmployeeById() throws Exception {
		long Employee_id = 1;
		Employee employee = mockedService.getEmployeeById(Employee_id);

		assertNotNull(employee);
		assertEquals(Employee_id, employee.getEmployee_id());
		assertEquals("PrafullaChandra", employee.getEmployee_name());
		assertEquals(30724, employee.getCreated_user_id());
		assertEquals(timestamp, employee.getCreated_dttm());
		assertEquals(1, employee.getUpdated_user_id());
		assertEquals(timestamp,employee.getUpdated_dttm());
		assertEquals(1, employee.getProject_id());
		assertEquals(true, employee.getStatus());

	}

	//To test whether all the employees are fetched
	@Test
	public void testGetAllEmployee() throws Exception {

		List<Employee> emp = mockedService.getAllEmployee();
		assertEquals(3, emp.size());
		Employee em = emp.get(0);
		assertEquals(1, em.getEmployee_id());
		assertEquals("PrafullaChandra", em.getEmployee_name());
		assertEquals(30724, em.getCreated_user_id());
		assertEquals(timestamp, em.getCreated_dttm());
		assertEquals(1, em.getUpdated_user_id());
		assertEquals(timestamp, em.getUpdated_dttm());
		assertEquals(1, em.getProject_id());
		assertEquals(true, em.getStatus());

	}

	//To test whether all the active employees are fetched
	@Test
	public void testGetActiveEmployee() throws Exception {

		List<Employee> emp1 = mockedService.getActiveEmployee();
		assertEquals(1, emp1.size());
		Employee emp = emp1.get(0);
		assertEquals(1, emp.getEmployee_id());
		assertEquals("PrafullaChandra", emp.getEmployee_name());
		assertEquals(30724, emp.getCreated_user_id());
		assertEquals(timestamp, emp.getCreated_dttm());
		assertEquals(1, emp.getUpdated_user_id());
		assertEquals(timestamp, emp.getUpdated_dttm());
		assertEquals(1, emp.getProject_id());
		assertEquals(true, emp.getStatus());



	}

	//To test whether the employee of particular id is deleted
	@Test
	public void testDeleteEmployee() throws Exception {
		long Employee_id = 3;
		boolean result = mockedService.deleteEmployee(Employee_id);
		assertNotNull(result);
		assertEquals(true, result);
	}

	// To test whether the employee is updated
	@Test
	public void testUpdateEmployee() throws Exception {
		boolean result = mockedService.UpdateEmployee(e1);
		assertNotNull(result);
		assertEquals(true, result);
	}


	//To test whether the customer of particular id is activated
	@Test
	public void testActivateEmployee() throws Exception {
		long employee_id = 2;
		boolean result = mockedService.activateEmployee(employee_id);
		assertNotNull(result);
		assertEquals(true, result);
	}

	//To test whether the customer of particular id is deactivated
	@Test
	public void testDeactivateEmployee() throws Exception {
		long employee_id = 1;
		boolean result = mockedService.deactivateEmployee(employee_id);
		assertNotNull(result);
		assertEquals(true, result);
	}

	//To test whether the employee of particular employee name and project id is fetched
	@Test
	public void testGetEmployeeByNameAndProjectId() throws Exception {
		String employee_name="PrafullaChandra";
		Employee employee= mockedService.getEmployeeByNameAndProjectId(employee_name, project_id);
		assertNotNull(employee);
		assertEquals(1, employee.getEmployee_id());
		assertEquals("PrafullaChandra", employee.getEmployee_name());
		assertEquals(30724, employee.getCreated_user_id());
		assertEquals(timestamp, employee.getCreated_dttm());
		assertEquals(1, employee.getUpdated_user_id());
		assertEquals(timestamp,employee.getUpdated_dttm());
		assertEquals(1, employee.getProject_id());
		assertEquals(true, employee.getStatus());

	}





}

