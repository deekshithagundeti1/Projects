package com.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.model.Project;
import com.service.ProjectService;



@RunWith(MockitoJUnitRunner.class)
public class ProjectTest {

	private static ProjectService mockedService;
	private static Project project1;
	private static Project project2;
	private static Project project3;
	static Timestamp timestamp= new Timestamp(System.currentTimeMillis());
	final static long customer_id=1;
	@BeforeClass
	public static void Setup() throws Exception {

		mockedService = mock(ProjectService.class);


		project1 = new Project((long)123,"Wunderman1",(long)123451,timestamp,timestamp,timestamp,(long)123452,timestamp,(long)123453,timestamp,true);

		project2 = new Project((long)456,"Wunderman2",(long)123454,timestamp,timestamp,timestamp,(long)123455,timestamp,(long)123456,timestamp,false);

		project3 = new Project((long)789,"Wunderman3",(long)123457,timestamp,timestamp,timestamp,(long)123458,timestamp,(long)123459,timestamp,true);

		//Stubbing the methods of mocked CustomerService with mocked data. 
		when(mockedService.getProjectList()).thenReturn(Arrays.asList(project1,project2,project3));
		when(mockedService.getProjectById((long) 123)).thenReturn(project1);
		when(mockedService.getProjectByName("Wunderman1",customer_id)).thenReturn(project1);
		when(mockedService.getProjectByNameAndCustomerId("Wunderman1", customer_id)).thenReturn(project1);
		when(mockedService.getProjectStatus((long) 123)).thenReturn(true);
		when(mockedService.addProject(project1)).thenReturn(project1.getProject_Id());
		when(mockedService.deleteProject((long) 123)).thenReturn(true);
		when(mockedService.activateProject((long) 987)).thenReturn(true);
		when(mockedService.deactivateProject((long) 123)).thenReturn(true);
		when(mockedService.updateProject(project1)).thenReturn(true);

	}


	//To test whether the customer is added
	@Test
	public void testAddCustomer() throws Exception {
		long id = mockedService.addProject(project1);
		Project project = mockedService.getProjectById(id);
		assertNotNull(id);
		assertNotNull(project);
		assertEquals(123, (long)project.getProject_Id());
		assertEquals("Wunderman1", project.getProject_Name());
		assertEquals(123451, (long)project.getProject_Description());
		assertEquals(timestamp, project.getProject_Start_Date());
		assertEquals(timestamp, project.getProject_End_Date());
		assertEquals(timestamp, project.getProject_Duration());
		assertEquals(123452, (long)project.getCreated_User_Id());
		assertEquals(timestamp, project.getCreated_Date_Time());
		assertEquals(123453, (long)project.getUpdated_User_id());
		assertEquals(timestamp, project.getUpdated_Date_Time());
		assertEquals(true, project.getStatus());

	}

	//To test whether the project of particular id is fetched
	@Test
	public void testGetProjectById() throws Exception {
		long project_id = 123;
		Project project= mockedService.getProjectById(project_id);

		assertNotNull(project);
		assertEquals(project_id, (long)project.getProject_Id());
		assertEquals("Wunderman1", project.getProject_Name());
		assertEquals(123451, (long)project.getProject_Description());
		assertEquals(timestamp, project.getProject_Start_Date());
		assertEquals(timestamp, project.getProject_End_Date());
		assertEquals(timestamp, project.getProject_Duration());
		assertEquals(123452, (long)project.getCreated_User_Id());
		assertEquals(timestamp, project.getCreated_Date_Time());
		assertEquals(123453, (long)project.getUpdated_User_id());
		assertEquals(timestamp, project.getUpdated_Date_Time());
		assertEquals(true, project.getStatus());

	}

	//To test whether the project of particular name is fetched
	@Test
	public void testGetProjectByName() throws Exception {
		String project_name="Wunderman1";
		Project project= mockedService.getProjectByName(project_name,customer_id);

		assertNotNull(project);
		assertEquals(123, (long)project.getProject_Id());
		assertEquals(project_name, project.getProject_Name());
		assertEquals(123451, (long)project.getProject_Description());
		assertEquals(timestamp, project.getProject_Start_Date());
		assertEquals(timestamp, project.getProject_End_Date());
		assertEquals(timestamp, project.getProject_Duration());
		assertEquals(123452, (long)project.getCreated_User_Id());
		assertEquals(timestamp, project.getCreated_Date_Time());
		assertEquals(123453, (long)project.getUpdated_User_id());
		assertEquals(timestamp, project.getUpdated_Date_Time());
		assertEquals(true, project.getStatus());

	}
	//To test whether the project of particular customer id and project name is fetched
	@Test
	public void testGetProjectByNameAndCustomerId() throws Exception {
		String project_name="Wunderman1";
		Project project= mockedService.getProjectByNameAndCustomerId(project_name, customer_id);

		assertNotNull(project);
		assertEquals(123, (long)project.getProject_Id());
		assertEquals(project_name, project.getProject_Name());
		assertEquals(123451, (long)project.getProject_Description());
		assertEquals(timestamp, project.getProject_Start_Date());
		assertEquals(timestamp, project.getProject_End_Date());
		assertEquals(timestamp, project.getProject_Duration());
		assertEquals(123452, (long)project.getCreated_User_Id());
		assertEquals(timestamp, project.getCreated_Date_Time());
		assertEquals(123453, (long)project.getUpdated_User_id());
		assertEquals(timestamp, project.getUpdated_Date_Time());
		assertEquals(true, project.getStatus());

	}

	//To test whether all the Projects are fetched
	@Test
	public void testGetProjectList() throws Exception {

		List<Project> projects = mockedService.getProjectList();
		assertEquals(3, projects.size());
		Project project= projects.get(0);
		assertEquals(123, (long)project.getProject_Id());
		assertEquals("Wunderman1", project.getProject_Name());
		assertEquals(123451, (long)project.getProject_Description());
		assertEquals(timestamp, project.getProject_Start_Date());
		assertEquals(timestamp, project.getProject_End_Date());
		assertEquals(timestamp, project.getProject_Duration());
		assertEquals(123452, (long)project.getCreated_User_Id());
		assertEquals(timestamp, project.getCreated_Date_Time());
		assertEquals(123453, (long)project.getUpdated_User_id());
		assertEquals(timestamp, project.getUpdated_Date_Time());
		assertEquals(true, project.getStatus());

	}
	//To test whether the project status is fetched
	@Test
	public void testGetProjectStatus() throws Exception {
		boolean result= mockedService.getProjectStatus((long) 123);
		assertNotNull(result);
		assertEquals(true, result);

	}


	//To test whether the project of particular id is deleted
	@Test
	public void testDeleteProject() throws Exception {
		long project_id = 123;
		boolean result = mockedService.deleteProject(project_id);
		assertNotNull(result);
		assertEquals(true, result);
	}

	//To test whether the project is updated
	@Test
	public void testUpdateProject() throws Exception {
		boolean result = mockedService.updateProject(project1);
		assertNotNull(result);
		assertEquals(true, result);
	}

	//To test whether the project of particular id is activated
	@Test
	public void testActivateProject() throws Exception {
		long project_id = 987;
		boolean result = mockedService.activateProject(project_id);
		assertNotNull(result);
		assertEquals(true, result);
	}

	//To test whether the project of particular id is deactivated
	@Test
	public void testDeactivateProject() throws Exception {
		long project_id = 123;
		boolean result = mockedService.deactivateProject(project_id);
		assertNotNull(result);
		assertEquals(true, result);
	}


}
