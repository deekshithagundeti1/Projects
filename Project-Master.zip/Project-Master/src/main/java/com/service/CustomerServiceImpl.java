package com.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.CustomerDao;
import com.model.Customer;



@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao dao;

	/*
	 * Adding a customer
	 * 
	 * @param customer object
	 * 
	 * @return long
	 */
	@Override
	public long addCustomer(Customer customer) {
		return dao.addCustomer(customer);
	}

	/*
	 * Fetching Customer by id
	 * 
	 * @param customer_id
	 * 
	 * @return Customer
	 */
	@Override
	public Customer getCustomerById(Long customer_id) {
		return dao.getCustomerById(customer_id);
	}
	/*
	 * Fetching all customers
	 * 
	 * @return list
	 */

	@Override
	public List<Customer> getAllCustomers() {
		return dao.getAllCustomers();
	}

	/*
	 * Fetching all active customers
	 * 
	 * @return list
	 */
	@Override
	public List<Customer> getAllActiveCustomers() {
		return dao.getAllActiveCustomers();
	}

	/*
	 * Deleting a customer
	 * 
	 * @param customer_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean deleteCustomerById(Long customer_id) {
		return dao.deleteCustomerById(customer_id);
	}

	/*
	 * Updating a customer
	 * 
	 * @param customer object
	 * 
	 * @return boolean
	 */
	@Override
	public boolean updateCustomer(Customer customer) {
		return dao.updateCustomer(customer);
	}

	/*
	 * Activating a customer
	 * 
	 * @param customer_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean activateCustomerById(Long customer_id) {
		return dao.activateCustomerById(customer_id);

	}

	/*
	 * Deactivating a customer
	 * 
	 * @param customer_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean deactivateCustomerById(Long customer_id) {
		return dao.deactivateCustomerById(customer_id);

	}
	
	/*
	 * Retrieving customer by name
	 * 
	 * @param customer_name
	 * 
	 * @return Customer Object
	 */
	@Override
	public Customer getCustomerByName(String customer_name) {
		return dao.getCustomerByName(customer_name);
	}
	

}