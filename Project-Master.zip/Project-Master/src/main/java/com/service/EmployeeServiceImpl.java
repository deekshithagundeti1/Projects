package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dao.EmployeeDao;
import com.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@SuppressWarnings("unused")
	private JdbcTemplate jdbcTemplate;

	@Autowired
	EmployeeDao employeeDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.service.EmployeeService#addEmp(com.model.Employee)
	 */
	@Override
	public long addEmployee(Employee employee) {
		return employeeDao.addEmployee(employee);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.service.EmployeeService#UpdateEmp(com.model.Employee)
	 */
	@Override
	public boolean UpdateEmployee(Employee employee) {
		return employeeDao.UpdateEmployee(employee);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.service.EmployeeService#getAllEmployee()
	 */
	@Override
	public List<Employee> getAllEmployee() {
		return employeeDao.getAllEmployee();
	}

	// Service Implementation method for displaying all active employee
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.service.EmployeeService#ActEmp()
	 */
	@Override
	public List<Employee> getActiveEmployee() {
		return employeeDao.getActiveEmployee();
	}

	// Service Implementation method for deleting an employee details
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.service.EmployeeService#deleteEmp(long)
	 */
	@Override
	public boolean deleteEmployee(long Employee_id) {
		return employeeDao.deleteEmployee(Employee_id);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.service.EmployeeService#getEmployeeById(long)
	 */
	@Override
	public Employee getEmployeeById(long Employee_id) {
		return employeeDao.getEmployeeById(Employee_id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.service.EmployeeService#getEmployeeByNameAndProjectId(java.lang.
	 * String, java.lang.Long)
	 */
	@Override
	public Employee getEmployeeByNameAndProjectId(String employeeName, Long project_id) {
		return employeeDao.getEmployeeByNameAndProjectId(employeeName, project_id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.service.EmployeeService#activateEmployee(java.lang.Long)
	 */
	@Override
	public boolean activateEmployee(Long employee_Id) {
		return employeeDao.activateEmployee(employee_Id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.service.EmployeeService#deactivateEmployee(java.lang.Long)
	 */
	@Override
	public boolean deactivateEmployee(Long employee_Id) {
		return employeeDao.deactivateEmployee(employee_Id);
	}

}
