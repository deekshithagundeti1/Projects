package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dao.CostDao;
import com.model.Cost;

@Service
public class CostServiceImpl  implements CostService{


	@SuppressWarnings("unused")
	private JdbcTemplate jdbcTemplate;
	
	
	@Autowired
	CostDao costDao;

	/*
	 * Adding a cost
	 * 
	 * @param cost object
	 * 
	 * @return long
	 */
	@Override
	public long addCost(Cost costData) {
		return costDao.addCost(costData);
	}

	/*
	 * Fetching Cost by id
	 * 
	 * @param cost_master_id
	 * 
	 * @return Cost
	 */
	@Override
	public Cost getCostById(long cost_master_id) {
		return costDao.getCostById(cost_master_id);
	}

	/*
	 * Updating a cost
	 * 
	 * @param cost object
	 * 
	 * @return boolean
	 */
	@Override
	public boolean updateCost(Cost costData) {
		return costDao.updateCost(costData);
	}

	/*
	 * fetching cost for all projects
	 *  
	 * @param cost object
	 * 
	 * @return boolean
	 */
	@Override
	public List<Cost> getCostForAllProjects() {
		return costDao.getCostForAllProjects();
	}

	/*
	 * Deleting a cost
	 * 
	 * @param cost_master_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean deleteCost(long cost_id) {
		return costDao.deleteCost(cost_id);
	}

	/*
	 * fetching cost by projectId
	 *  
	 * @param cost object
	 * 
	 * @return boolean
	 */
	@Override
	public Cost getCostByProjectId(long project_id) {
		return costDao.getCostByProjectId(project_id);
	}

	/*
	 * Activating a cost
	 * 
	 * @param cost_master_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean activateCost(long cost_id) {
		return costDao.activateCost(cost_id);
	}

	/*
	 * Deactivating a cost
	 * 
	 * @param cost_master_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean deactivateCost(long cost_id) {
		return costDao.deactivateCost(cost_id);
	}


	

}
