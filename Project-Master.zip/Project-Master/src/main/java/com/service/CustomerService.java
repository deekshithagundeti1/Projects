package com.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Customer;



@Service
public interface CustomerService {

	/*
	 * Adding a customer
	 * 
	 * @param customer object
	 * 
	 * @return long
	 */
	public long addCustomer(Customer customer);

	/*
	 * Fetching Customer by id
	 * 
	 * @param customer_id
	 * 
	 * @return Customer
	 */
	public Customer getCustomerById(Long customer_id);

	/*
	 * Fetching all customers
	 * 
	 * @return list
	 */
	public List<Customer> getAllCustomers();


	/*
	 * Fetching all active customers
	 * 
	 * @return list
	 */
	public List<Customer> getAllActiveCustomers();

	/*
	 * Deleting a customer
	 * 
	 * @param customer_id
	 * 
	 * @return boolean
	 */
	public boolean deleteCustomerById(Long customer_id);

	/*
	 * Updating a customer
	 * 
	 * @param customer object
	 * 
	 * @return boolean
	 */
	public boolean updateCustomer(Customer customer);

	/*
	 * Activating a customer
	 * 
	 * @param customer_id
	 * 
	 * @return boolean
	 */
	public boolean activateCustomerById(Long customer_id);

	/*
	 * Deactivating a customer
	 * 
	 * @param customer_id
	 * 
	 * @return boolean
	 */
	public boolean deactivateCustomerById(Long customer_id);

		
	/*
	 * Retrieving customer by name
	 * 
	 * @param customer_name
	 * 
	 * @return Customer Object
	 */
	public Customer getCustomerByName(String customer_name);
	

}
