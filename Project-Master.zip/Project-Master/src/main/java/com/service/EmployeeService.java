package com.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Employee;

@Service
public interface EmployeeService {
	/**
	 * 
	 * @return list of all employee
	 */

	public List<Employee> getAllEmployee();

	/**
	 * 
	 * @param Employee_id
	 * @return the particular employee details
	 */

	public Employee getEmployeeById(long Employee_id);

	/**
	 * 
	 * @param em
	 * @return the id of added employee
	 */

	public long addEmployee(Employee employee);

	/**
	 * 
	 * @param Employee_id
	 * @return deleted status
	 */

	public boolean deleteEmployee(long Employee_id);

	/**
	 * 
	 * @param em
	 */

	public boolean UpdateEmployee(Employee employee);

	/**
	 * 
	 * @return the list of active employee
	 */
	public List<Employee> getActiveEmployee();

	/**
	 * @param employeeName
	 * @param project_id
	 * @return {@link Employee}
	 */
	public Employee getEmployeeByNameAndProjectId(String employeeName, Long project_id);

	/**
	 * @param employee_Id
	 * @return boolean
	 */
	public boolean activateEmployee(Long employee_Id);

	/**
	 * @param employee_Id
	 * @return boolean
	 */
	public boolean deactivateEmployee(Long employee_Id);

}
