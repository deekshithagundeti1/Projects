package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ProjectDao;
import com.model.Project;


@Service
public class ProjectServiceImpl implements ProjectService{

	@Autowired
	ProjectDao daoInterface;


	/* (non-Javadoc)
	 * @see com.service.ServiceInterface#addProject(com.model.ProjectMasterModel, java.lang.String)
	 */
	@Override
	public long addProject(Project projectData) {
		return daoInterface.addProject(projectData);
	}


	/* (non-Javadoc)
	 * @see com.service.ServiceInterface#getProjectById(long)
	 */
	@Override
	public Project getProjectById(long id) {
		return daoInterface.getProjectById(id);
	}


	/* (non-Javadoc)
	 * @see com.service.ServiceInterface#getProjectList()
	 */
	@Override
	public List<Project> getProjectList() {
		return daoInterface.getProjectList();
	}


	/* (non-Javadoc)
	 * @see com.service.ServiceInterface#updateProject(com.model.ProjectMasterModel)
	 */
	@Override
	public boolean updateProject(Project projectData) {
		return daoInterface.updateProject(projectData);
	}


	/* (non-Javadoc)
	 * @see com.service.ServiceInterface#deleteProject(java.lang.Long)
	 */
	@Override
	public boolean deleteProject(Long project_ID) {
		return daoInterface.deleteProject(project_ID);
	}


	/* (non-Javadoc)
	 * @see com.service.ServiceInterface#deactivateProject(java.lang.Long)
	 */
	@Override
	public boolean deactivateProject(Long project_id) {
		return daoInterface.deactivateProject(project_id);
	}


	/* (non-Javadoc)
	 * @see com.service.ServiceInterface#getProjectStatus(java.lang.Long)
	 */
	@Override
	public boolean getProjectStatus(Long project_Id) {
		return daoInterface.getProjectStatus(project_Id);
	}


	/* (non-Javadoc)
	 * @see com.service.ServiceInterface#activateProject(java.lang.Long)
	 */
	@Override
	public boolean activateProject(Long project_id) {
		return daoInterface.activateProject(project_id);
	}


	/* (non-Javadoc)
	 * @see com.service.ServiceInterface#getProjectByName(java.lang.String, java.lang.String)
	 */
	@Override
	public Project getProjectByName(String projectName, Long customer_Id) {
		// TODO Auto-generated method stub
		System.out.println("check");
		return daoInterface.getProjectByName(projectName, customer_Id);
	}


	/* (non-Javadoc)
	 * @see com.service.ProjectService#getProjectEmp(java.lang.Long)
	 */
	@Override
	public Project getProjectEmp(Long id) {
		return daoInterface.getProjectEmp(id);
	}


	/* (non-Javadoc)
	 * @see com.service.ProjectService#getProjectByNameAndCustomerId(java.lang.String, long)
	 */
	@Override
	public Project getProjectByNameAndCustomerId(String project_Name, long customer_id) {
		return daoInterface.getProjectByNameAndCustomerId(project_Name, customer_id);
	}

}
