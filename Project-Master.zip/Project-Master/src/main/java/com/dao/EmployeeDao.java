package com.dao;

import java.util.List;

import com.model.Employee;

public interface EmployeeDao {

	/**
	 * Fetches the list of all employee
	 * 
	 * @return list
	 */

	public List<Employee> getAllEmployee();

	/**
	 * 
	 * @param Employee_id
	 * @return employee details of particular id
	 */

	public Employee getEmployeeById(long Employee_id);

	/**
	 * @param Employee
	 * @return id of newly added project
	 */
	public long addEmployee(Employee em);

	/**
	 * @param Employee_id
	 * @return status
	 */

	public boolean deleteEmployee(long Employee_id);

	/**
	 * @param Employee
	 * @return status
	 */

	public boolean UpdateEmployee(Employee em);

	/**
	 * Fetches the list of active employee
	 * 
	 * @return list
	 */

	public List<Employee> getActiveEmployee();

	/**
	 * @param employeeName
	 * @param project_id
	 * @return {@link Employee}
	 */
	public Employee getEmployeeByNameAndProjectId(String employeeName, Long project_id);

	/**
	 * @param employee_Id
	 * @return boolean
	 */
	public boolean activateEmployee(Long employee_Id);

	/**
	 * @param employee_Id
	 * @return boolean
	 */
	public boolean deactivateEmployee(Long employee_Id);

}
