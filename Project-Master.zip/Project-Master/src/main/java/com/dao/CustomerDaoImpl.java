package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Repository.CustomerRepository;
import com.exception_handler.EntityNotFoundException;
import com.exception_handler.InvalidAttributes;
import com.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	@Autowired
	CustomerRepository customerRepository;

	/*
	 * Adding a customer
	 * 
	 * @param customer object
	 * 
	 * @return long
	 */
	@Override
	public long addCustomer(Customer NewCustomer) {
		Customer ExistingCustomer = customerRepository.getCustomerByName(NewCustomer.getCustomer_name());
		// Checking existing customer
		if (ExistingCustomer != null)
			throw new InvalidAttributes(NewCustomer.getCustomer_name() + ": Customer name already exist");

		// Checking null values
		String NewCustomerStatus = checkCustomerAttributes(NewCustomer);
		if (NewCustomerStatus != null)
			throw new InvalidAttributes(NewCustomerStatus + " cannot be null");

		long customerId = customerRepository.addCustomer(NewCustomer);
		if (customerId > 0) {
			return customerId;
		} else
			throw new InvalidAttributes("Invalid Request: Kindly enter the mandatory fields");
	}


	/*
	 * Fetching Customer by id
	 * 
	 * @param customer_id
	 * 
	 * @return Customer
	 */
	@Override
	public Customer getCustomerById(Long customer_id) {
		Customer customer = customerRepository.getCustomerById(customer_id);
		if (customer == null)
			throw new EntityNotFoundException(customer_id + ": Invalid customer Id");
		else if (!customer.getStatus())
			throw new InvalidAttributes(customer_id + ": Customer is inactive");
		else
			return customer;
	}

	/*
	 * Fetching all customers
	 * 
	 * @return list
	 */
	@Override
	public List<Customer> getAllCustomers() {
		List<Customer> customerList = customerRepository.getAllCustomers();
		if (customerList.size() != 0) {
			return customerList;
		} else
			throw new EntityNotFoundException("No customers found");

	}


	/*
	 * Fetching all active customers
	 * 
	 * @return list
	 */
	@Override
	public List<Customer> getAllActiveCustomers() {

		List<Customer> customerList = customerRepository.getAllActiveCustomers();
		if (customerList.size() != 0) {
			return customerList;
		} else
			throw new InvalidAttributes("No active customers found");
	}

	/*
	 * Deleting a customer
	 * 
	 * @param customer_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean deleteCustomerById(Long customer_id) {
		if (customerRepository.deleteCustomerById(customer_id))
			return true;

		throw new InvalidAttributes(customer_id + ": Not found. Enter the correct id");
	}

	/*
	 * Updating a customer
	 * 
	 * @param customer object
	 * 
	 * @return boolean
	 */
	@Override
	public boolean updateCustomer(Customer updatedCustomer) {

		// Checking null values
		String UpdatedCustomerStatus = checkCustomerAttributes(updatedCustomer);
		if (UpdatedCustomerStatus != null)
			throw new InvalidAttributes(UpdatedCustomerStatus + " cannot be null");

		// Checking if already exist and same name customer
		Customer existingCustomer = customerRepository.getCustomerById(updatedCustomer.getCustomer_id());

		// check if already exist
		if (existingCustomer == null)
			throw new EntityNotFoundException(updatedCustomer.getCustomer_id() + ": Customer not found");

		if (updatedCustomer.getCustomer_id() == 0)
			throw new EntityNotFoundException(updatedCustomer.getCustomer_id() + ": customer_id cannot be 0");

		if (customerRepository.updateCustomer(updatedCustomer)) {
			return true;
		} else
			throw new InvalidAttributes("Customer cannot be updated");
	}

	/*
	 * Activating a customer
	 * 
	 * @param customer_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean activateCustomerById(Long customerId) {
		// checking if already exist
		if (customerRepository.getCustomerById(customerId) == null)
			throw new EntityNotFoundException(customerId + ": Customer not found");

		if (customerRepository.activateCustomerById(customerId)) 
			return true;

		throw new InvalidAttributes(customerId + ": Customer cannot be activated");
	}

	/*
	 * Deactivating a customer
	 * 
	 * @param customer_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean deactivateCustomerById(Long customerId) {

		// checking if already exist
		if (customerRepository.getCustomerById(customerId) == null)
			throw new EntityNotFoundException(customerId + ": Customer not found");

		if (customerRepository.deactivateCustomerById(customerId)) 
			return true;

		throw new InvalidAttributes(customerId + ": Customer cannot be deactivated");
	}

	@Override
	public Customer getCustomerByName(String customer_name) {
		try {
			return customerRepository.getCustomerByName(customer_name);
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

	/**
	 * @param Customer
	 * @return String
	 */
	public String checkCustomerAttributes(Customer NewCustomer) {
		String result = "";
		if (NewCustomer.getCustomer_name().trim().isEmpty() || NewCustomer.getCustomer_name() == null)
			result += " ,Customer Name";
		if (NewCustomer.getCreated_user_id() == 0)
			result += " ,Created User Id";
		if (NewCustomer.getCreated_dttm() == null)
			result += " ,Created user timestamp";

		return (result.equals("")) ? null : result.substring(2);
	}
}