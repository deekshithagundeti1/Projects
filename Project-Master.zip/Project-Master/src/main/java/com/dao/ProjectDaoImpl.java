package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Repository.CustomerRepository;
import com.Repository.ProjectRepository;
import com.exception_handler.EntityNotFoundException;
import com.exception_handler.InvalidAttributes;
import com.model.Customer;
import com.model.Project;


/**
 * @author 768851
 *
 */
@Repository
public class ProjectDaoImpl implements ProjectDao {

	@Autowired
	ProjectRepository projectRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public long addProject(Project projectData) {
		//Checking null values
		String newProjectstatus = checkAttributes(projectData);
		if(newProjectstatus!=null)
			throw new InvalidAttributes(newProjectstatus+" cannot be null");

		//check if customer exist
		Customer customerData = customerRepository.getCustomerById(projectData.getCreated_User_Id());
		if ( customerData == null)
			throw new EntityNotFoundException("Invalid customer Id: "+projectData.getCreated_User_Id());

		//check same name project
		if (projectRepository.getProjectByNameAndCustomerId(projectData.getProject_Name(), customerData.getCustomer_id()) != null)
			throw new InvalidAttributes(projectData.getProject_Name() + ": Project name already exist");

		//adding project
		long projectId = projectRepository.addProject(projectData, customerData.getCustomer_id());
		if (projectId > 0)
			return projectId;
		else
			throw new InvalidAttributes("Invalid Request: Kindly enter the mandatory fields");	

	}

	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#getProjectById(long)
	 */
	@Override
	public Project getProjectById(long project_id) {
		//check if exist
		Project projectData = projectRepository.getProjectById(project_id);
		if (projectData == null)
			throw new EntityNotFoundException("Invalid project Id: "+project_id);

		//checking the status of the project
		else if (!projectData.getStatus())
			throw new InvalidAttributes("Project is not active");
		else
			return projectData;

	}


	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#getProjectList()
	 */
	@Override
	public List<Project> getProjectList() {
		List<Project> projectList = projectRepository.getProjectList();

		//Checking active projects
		if (projectList.size() != 0)
			return projectList;
		else 
			throw new EntityNotFoundException("No projects found");
	}


	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#updateProject(com.model.Project)
	 */
	@Override
	public boolean updateProject(Project projectData) {
		//checking null values
		String projectStatus = checkAttributes(projectData);
		if(projectStatus!=null)
			throw new InvalidAttributes(projectStatus);
		//Checking the possibility of conflict of same name
		else if(projectRepository.getProjectByName(projectData.getProject_Name(), projectData.getCreated_User_Id())!=null)
			throw new InvalidAttributes("project with same name already exist");


		if (projectRepository.updateProject(projectData))
			return true;
		else
			throw new InvalidAttributes("Improper Inputs");
	}


	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#deleteProject(java.lang.Long)
	 */
	@Override
	public boolean deleteProject(Long project_Id) {
		if (projectRepository.deleteProject(project_Id))
			return true;
		else
			throw new InvalidAttributes(project_Id + ": Not found. Kindly enter the correct id");
	}


	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#activateProject(java.lang.Long)
	 */
	@Override
	public boolean activateProject(Long project_id) {
		if (projectRepository.activateProject(project_id))
			return true;
		else
			throw new InvalidAttributes(project_id + ": Project not found");
	}


	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#deactivateProject(java.lang.Long)
	 */
	@Override
	public boolean deactivateProject(Long id) {

		if (projectRepository.deactivateProject(id))
			return true;
		else
			throw new InvalidAttributes(id + ": Project not found");
	}



	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#getProjectStatus(java.lang.Long)
	 */
	@Override
	public boolean getProjectStatus(Long project_Id) {
		try {
			return projectRepository.getProjectStatus(project_Id);
		} catch (Exception e) {
			return false;
		}
	}


	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#getProjectByName(java.lang.String, java.lang.Long)
	 */
	@Override
	public Project getProjectByName(String projectName, Long customer_Id) {
		try {
			return projectRepository.getProjectByName(projectName, customer_Id);
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}



	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#getProjectEmp(java.lang.Long)
	 */
	@Override
	public Project getProjectEmp(Long id) {
		try {
			return projectRepository.getProjectEmp(id);
		} catch (Exception e) {

			return null;
		}
	}





	/* (non-Javadoc)
	 * @see com.dao.ProjectDao#getProjectByNameAndCustomerId(java.lang.String, long)
	 */
	@Override
	public Project getProjectByNameAndCustomerId(String project_Name, long customer_id) {
		try {
			return projectRepository.getProjectByNameAndCustomerId(project_Name,customer_id);
		} catch (Exception e) {
			return null;
		}
	}

	//Checking null values while inserting
	public String checkAttributes(Project projectData){
		String result = "";
		if(projectData.getProject_Name().trim().isEmpty()||projectData.getProject_Name()==null)
			result+= " ,project Name";
		if(projectData.getCreated_User_Id()==0)
			result+= " ,created User Id";
		if(projectData.getCreated_Date_Time()==null)
			result+= " ,created user timestamp";
		if(projectData.getProject_Start_Date()==null)
			result+= " ,project start date";
		if(projectData.getProject_End_Date()==null)
			result+= " ,project end date";
		if(projectData.getProject_Duration()==null)
			result+= " ,project duration";
		if(projectData.getProject_Description()==null)
			result+= " ,project description";

		return (result.equals(""))? null:result.substring(2);
	}



}
