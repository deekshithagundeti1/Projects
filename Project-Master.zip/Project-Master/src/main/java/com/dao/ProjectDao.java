package com.dao;


import java.util.List;

import com.model.Project;

/**
 * @author 768851
 *
 */
public interface ProjectDao {

	/**
	 * @param projectData
	 * @param customerName
	 * @return id of newly added project 
	 */
	public long addProject(Project projectData);


	/**
	 * @param id
	 * @return {@link Project}
	 */
	public Project getProjectById(long id);


	/**
	 * @return list of {@link Project} objects
	 */
	public List<Project> getProjectList();


	/**
	 * @param projectData
	 * @return true or false
	 */
	public boolean updateProject(Project projectData);


	/**
	 * @param project_ID
	 * @return true or false
	 */
	public boolean deleteProject(Long project_ID);


	/**
	 * @param project_id
	 * @return true or false
	 */
	public boolean activateProject(Long project_id);


	/**
	 * @param project_id
	 * @return true or false
	 */
	public boolean deactivateProject(Long project_id);


	/**
	 * @param project_Id
	 * @return true or false
	 */
	public boolean getProjectStatus(Long project_Id);


	/**
	 * @param projectName
	 * @param customerName
	 * @return {@link Project} object
	 */
	public Project getProjectByName(String projectName, Long customer_Id);


	/**
	 * @param customer_id
	 * @return {@link Project}
	 */
	public Project getProjectEmp(Long id);


	/**
	 * @param project_Name
	 * @param customer_id
	 * @return
	 */
	public Project getProjectByNameAndCustomerId(String project_Name, long customer_id);
}
