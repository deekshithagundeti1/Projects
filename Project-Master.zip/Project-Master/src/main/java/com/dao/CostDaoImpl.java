package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Repository.CostRepository;
import com.Repository.ProjectRepository;
import com.exception_handler.EntityNotFoundException;
import com.exception_handler.InvalidAttributes;
import com.model.Cost;

@Repository
public class CostDaoImpl implements CostDao {

	@Autowired
	private CostRepository costRepository;

	@Autowired
	private ProjectRepository projectRepository;

	/*
	 * Adding a cost
	 * 
	 * @param cost object
	 * 
	 * @return long
	 */
	@Override
	public long addCost(Cost costData) {
		//Checking for the null values
		String costDataInputValueStatus = checkCostAttributes(costData);
		if(costDataInputValueStatus!=null)
			throw new InvalidAttributes(costDataInputValueStatus+" cannot be null");

		//check if project exist or not
		if(projectRepository.getProjectById(costData.getProject_id())==null)
			throw new EntityNotFoundException("Invalid project id");

		//checking if cost for particular project already exist
		if(costRepository.getCostByProjectId(costData.getProject_id())!=null)
			throw new InvalidAttributes("Cost already exist for project id "+costData.getProject_id());

		long cost_id =  costRepository.addCost(costData);

		if(cost_id>0) return cost_id;

		throw new InvalidAttributes("Invalid inputs");

	}

	/*
	 * Fetching Cost by id
	 * 
	 * @param cost_master_id
	 * 
	 * @return Cost
	 */
	@Override
	public Cost getCostById(long cost_master_id) {

		Cost costData = costRepository.getCostById(cost_master_id); 

		//Checking if cost exist
		if(costData==null) 
			throw new EntityNotFoundException("Invalid cost id");

		//Checking if the cost is active
		else if(!costData.getStatus()) 
			throw new InvalidAttributes("Cost is not active");

		return costData;
	}

	/*
	 * Updating a cost
	 * 
	 * @param cost object
	 * 
	 * @return boolean
	 */
	@Override
	public boolean updateCost(Cost costData) {
		//Checking for the null values
		String costDataInputValueStatus = checkCostAttributes(costData);
		if(costDataInputValueStatus!=null)
			throw new InvalidAttributes(costDataInputValueStatus+" cannot be null");

		//check if project exist or not
		if(projectRepository.getProjectById(costData.getProject_id())==null)
			throw new EntityNotFoundException("Invalid project id");

		if(costRepository.updateCost(costData))
			return true;
		else
			throw new InvalidAttributes("Cannot connect to database");
	}

	/*
	 * fetching cost for all projects
	 * 
	 * @param cost object
	 * 
	 * @return boolean
	 */
	@Override
	public List<Cost> getCostForAllProjects() {

		List<Cost> costList = costRepository.getCostForAllProjects();

		//checking if list is null
		if(costList.size()==0||costList==null)
			throw new EntityNotFoundException("No cost for any project exist");

		return costList;
	}

	/*
	 * Deleting a cost
	 * 
	 * @param cost_master_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean deleteCost(long cost_id) {
		if(costRepository.deleteCost(cost_id))
			return true;

		throw new EntityNotFoundException("Invalid cost id");
	}

	/*
	 * fetching cost by projectId
	 * 
	 * @param cost object
	 * 
	 * @return boolean
	 */
	@Override
	public Cost getCostByProjectId(long project_id) {
		return costRepository.getCostByProjectId(project_id);
	}

	/*
	 * Activating a cost
	 * 
	 * @param cost_master_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean activateCost(long cost_id) {
		if (costRepository.activateCost(cost_id)) {
			return true;
		} else
			throw new InvalidAttributes(cost_id + ": Cost not found");
	}

	/*
	 * Deactivating a cost
	 * 
	 * @param cost_master_id
	 * 
	 * @return boolean
	 */
	@Override
	public boolean deactivateCost(long cost_id) {
		if(costRepository.deactivateCost(cost_id)){
			return true;
		}else throw new InvalidAttributes(cost_id+": Customer not found");
	}

	/**
	 * @param Customer
	 * @return String
	 */
	public String checkCostAttributes(Cost newCost){
		String result = "";
		if(newCost.getProject_id()<0)
			result+= " ,Project_id";
		if(newCost.getCreated_user_id()==0)
			result+= " ,Created User Id";
		if(newCost.getCreated_dttm()==null)
			result+= " ,Created user timestamp";

		return (result.equals(""))? null:result.substring(2);
	}

}