package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

//import com.employeemaster.model.EmployeeRef;
import com.Repository.EmployeeRepository;
import com.exception_handler.EntityNotFoundException;
import com.exception_handler.InvalidAttributes;
import com.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	EmployeeRepository employeeRepository;

	// Method for retrieving all employee details
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dao.EmployeeDao#getAllEmployee()
	 */
	public List<Employee> getAllEmployee() {

		List<Employee> list = employeeRepository.getAllEmployee();

		//checking if the list is empty
		if(list.size()==0||list==null)
			throw new EntityNotFoundException("No Employees found");
		else
			return list;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dao.EmployeeDao#getEmployee(long)
	 */


	@Override
	public Employee getEmployeeById(long Employee_id) {
		//Checking validity of employee_id 
		if(Employee_id<=0)
			throw new InvalidAttributes(Employee_id+": Invalid Employee Id");

		//Checking if Employee exist
		Employee employee = employeeRepository.getEmployeeById(Employee_id);
		if(employee==null)
			throw new InvalidAttributes("Invalid employee Id");

		//Checking if the project is inactive
		else if(!employee.getStatus())
			throw new InvalidAttributes("Project is inactive");

		return employee;

	}

	// Method for adding a new employee details
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dao.EmployeeDao#addEmp(com.model.Employee)
	 */

	@Override
	public long addEmployee(Employee newEmployee) {	
		//Checking null input values
		String inputStatus = checkEmployeeAttributes(newEmployee);
		if(inputStatus!=null)
			throw new InvalidAttributes(inputStatus+" cannot be null");

		//Checking if same name employee already exist in a project
		if(employeeRepository.getEmployeeByNameAndProjectId(newEmployee.getEmployee_name(),newEmployee.getProject_id())!=null)
			throw new InvalidAttributes("employee of name"+newEmployee.getEmployee_name()+
					" already exist under the same project");

		//adding employee
		long employee_id = employeeRepository.addEmployee(newEmployee);
		if(employee_id>0)
			return employee_id;
		else
			throw new InvalidAttributes("Cannot connect to database");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dao.EmployeeDao#getEmployeeByNameAndProjectId(java.lang.String,
	 * java.lang.Long)
	 */

	@Override
	public Employee getEmployeeByNameAndProjectId(String employeeName, Long project_id) {
		return employeeRepository.getEmployeeByNameAndProjectId(employeeName, project_id);
	}

	// Method to delete a particular employee details
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dao.EmployeeDao#deleteEmp(long)
	 */

	@Override
	public boolean deleteEmployee(long Employee_id) {
		//Check if the employee exist
		if(employeeRepository.getEmployeeById(Employee_id)==null)
			throw new InvalidAttributes("Kindly enter the correct employee id");

		else if(employeeRepository.deleteEmployee(Employee_id))
			return true;
		else
			throw new InvalidAttributes("Cannot connect to database");

	}

	// Method to update the employee details
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dao.EmployeeDao#UpdateEmp(com.model.Employee)
	 */

	@Override
	public boolean UpdateEmployee(Employee employee) {
		//Checking null input values
		String inputStatus = checkEmployeeAttributes(employee);
		if(inputStatus!=null)
			throw new InvalidAttributes(inputStatus+" cannot be null");

		//adding employee
		if(employeeRepository.UpdateEmployee(employee))
			return true;
		else
			throw new InvalidAttributes("Cannot connect to database");
	}

	// Method to display the list of active employee
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dao.EmployeeDao#ActEmp()
	 */

	@Override
	public List<Employee> getActiveEmployee() {

		List<Employee> activeEmployeeList = employeeRepository.getActiveEmployee();

		//checking if the list is empty
		if(activeEmployeeList.size()==0||activeEmployeeList==null)
			throw new EntityNotFoundException("No active employee found");

		return activeEmployeeList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dao.EmployeeDao#activateEmployee(java.lang.Long)
	 */

	@Override
	public boolean activateEmployee(Long employee_Id) {
		//Checking the employee id
		if(employeeRepository.getEmployeeById(employee_Id)==null)
			throw new EntityNotFoundException("Invalid employee id");
		else if(employeeRepository.activateEmployee(employee_Id))
			return true;
		else
			throw new InvalidAttributes("Cannot connect to database");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dao.EmployeeDao#deactivateEmployee(java.lang.Long)
	 */
	@Override
	public boolean deactivateEmployee(Long employee_Id) {
		//Checking the employee id
		if(employeeRepository.getEmployeeById(employee_Id)==null)
			throw new EntityNotFoundException("Invalid employee id");
		else if(employeeRepository.deactivateEmployee(employee_Id))
			return true;
		else
			throw new InvalidAttributes("Cannot connect to database");
	}


	/**
	 * @param Customer
	 * @return String
	 */
	public String checkEmployeeAttributes(Employee newEmployee){
		String result = "";
		if(newEmployee.getEmployee_name().trim().isEmpty()||newEmployee.getEmployee_name()==null)
			result+= " ,Customer Name";
		if(newEmployee.getCreated_user_id()==0)
			result+= " ,Created User Id";
		if(newEmployee.getCreated_dttm()==null)
			result+= " ,Created user timestamp";

		return (result.equals(""))? null:result.substring(2);
	}


}
