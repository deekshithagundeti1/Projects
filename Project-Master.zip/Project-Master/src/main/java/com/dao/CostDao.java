package com.dao;

import java.util.List;

import com.model.Cost;

public interface CostDao {
	/*
	 * Adding a cost
	 * 
	 * @param cost object
	 * 
	 * @return long
	 */
	public long addCost(Cost costData);
	/*
	 * Fetching Cost by id
	 * 
	 * @param cost_master_id
	 * 
	 * @return Cost
	 */
	public Cost getCostById(long cost_master_id);
	/*
	 * Updating a cost
	 * 
	 * @param cost object
	 * 
	 * @return boolean
	 */
	public boolean updateCost(Cost costData);
	/*
	 * fetching cost for all projects
	 *  
	 * @param cost object
	 * 
	 * @return boolean
	 */
	public List<Cost> getCostForAllProjects();
	/*
	 * Deleting a cost
	 * 
	 * @param cost_master_id
	 * 
	 * @return boolean
	 */
	public boolean deleteCost(long Employee_id);
	/*
	 * fetching cost by projectId
	 *  
	 * @param cost object
	 * 
	 * @return boolean
	 */
	public Cost getCostByProjectId(long project_id);
	/*
	 * Activating a cost
	 * 
	 * @param cost_master_id
	 * 
	 * @return boolean
	 */
	public boolean activateCost(long cost_id);
	/*
	 * Deactivating a cost
	 * 
	 * @param cost_master_id
	 * 
	 * @return boolean
	 */
	public boolean deactivateCost(long cost_id);

}
