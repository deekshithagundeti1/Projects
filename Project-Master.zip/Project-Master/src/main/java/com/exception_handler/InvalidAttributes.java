package com.exception_handler;

public class InvalidAttributes extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidAttributes() {
		// TODO Auto-generated constructor stub
	}

	public InvalidAttributes(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidAttributes(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidAttributes(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidAttributes(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
