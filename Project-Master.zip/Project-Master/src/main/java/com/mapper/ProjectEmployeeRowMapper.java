package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.model.Employee;
import com.model.Project;


public class ProjectEmployeeRowMapper implements RowMapper<Project> {

	@Override
	public Project mapRow(ResultSet rs, int rownum) throws SQLException {
		Project projectData = new Project();

		projectData.setProject_Id(rs.getLong("project_id"));
		projectData.setProject_Name(rs.getString("project_Name"));
		projectData.setProject_Description(rs.getLong("project_Description"));
		projectData.setProject_Start_Date(rs.getTimestamp("project_Start_Date"));
		projectData.setProject_End_Date(rs.getTimestamp("project_End_Date"));
		projectData.setProject_Duration(rs.getTimestamp("project_Duration"));
		projectData.setCreated_User_Id(rs.getLong("created_User_Id"));
		projectData.setCreated_Date_Time(rs.getTimestamp("created_dttm"));
		projectData.setUpdated_User_id(rs.getLong("updated_User_Id"));
		projectData.setUpdated_Date_Time(rs.getTimestamp("updated_dttm"));
		projectData.setStatus(rs.getBoolean("status"));
		projectData.setEmployee(EmployeeMapper(rs));

		return projectData;
	}

	public List<Employee> EmployeeMapper(ResultSet rs) throws SQLException {
		List<Employee> EmpData = new ArrayList<Employee>();
		do {

			Employee obj = new Employee(rs.getLong("employee_id"), rs.getString("employee_name"),
					rs.getLong("created_user_id"), rs.getTimestamp("created_dttm"), rs.getLong("updated_user_id"),
					rs.getTimestamp("updated_dttm"),rs.getLong("project_id"), rs.getBoolean("status"));
			
			if(obj.getEmployee_id()!=0)
				EmpData.add(obj);
		} while (rs.next());

		return EmpData;
	}

}
