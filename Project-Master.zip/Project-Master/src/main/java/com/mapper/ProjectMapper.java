package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.jdbc.core.RowMapper;
import com.model.Employee;
import com.model.Project;

public class ProjectMapper implements RowMapper<Project> {

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
	 */
	@Override
	public Project mapRow(ResultSet rs, int rownum) throws SQLException {
		Project model = new Project();
		model.setProject_Id(rs.getLong("project_Id"));
		model.setProject_Name(rs.getString("project_Name"));
		model.setProject_Description(rs.getLong("project_Description"));
		model.setProject_Start_Date(rs.getTimestamp("project_Start_Date"));
		model.setProject_End_Date(rs.getTimestamp("project_End_Date"));
		model.setProject_Duration(rs.getTimestamp("project_Duration"));
		model.setCreated_User_Id(rs.getLong("created_User_Id"));
		model.setCreated_Date_Time(rs.getTimestamp("created_dttm"));
		model.setUpdated_User_id(rs.getLong("updated_User_Id"));
		model.setUpdated_Date_Time(rs.getTimestamp("updated_dttm"));
		model.setStatus(rs.getBoolean("status"));
		model.setEmployee(EmployeeMapper(rs));
		return model;
	}
	
	
	public List<Employee> EmployeeMapper(ResultSet rs) throws SQLException {
		try {
			List<Employee> EmpData = new ArrayList<Employee>();
			do {
				Employee obj = new Employee(rs.getLong("Employee_id"), rs.getString("Employee_name"),
						rs.getLong("Created_user_id"), rs.getTimestamp("Created_dttm"), 
						rs.getLong("Updated_user_id"),rs.getTimestamp("Updated_dttm"),
						rs.getLong("Project_id"), rs.getBoolean("Status"));
				EmpData.add(obj);
			} while (rs.next());

			return EmpData;
		} catch (Exception e) {
			return null;
		}
	}

}
