package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.Employee;

public class EmployeeMapper implements RowMapper<Employee> {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet,
	 * int)
	 */
	@Override
	public Employee mapRow(ResultSet result, int numRow) throws SQLException {
		return new Employee(result.getInt("employee_id"), result.getString("employee_name"),
				result.getInt("created_user_id"), result.getTimestamp("created_dttm"), result.getInt("updated_user_id"),
				result.getTimestamp("updated_dttm"), result.getInt("project_id"), result.getBoolean("status"));

	}

}
