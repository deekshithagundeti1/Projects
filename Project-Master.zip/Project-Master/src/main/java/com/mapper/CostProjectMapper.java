package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.model.Cost;
import com.model.Project;

public class CostProjectMapper implements RowMapper<Cost> {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet,
	 * int)
	 */
	@Override
	public Cost mapRow(ResultSet rs, int rownum) throws SQLException {
		Cost cost = new Cost();

		cost.setCost_master_id(rs.getLong("cost_master_id"));
		cost.setProject_id(rs.getLong("project_id"));
		cost.setLocation_id(rs.getLong("location_id"));
		cost.setCreated_user_id(rs.getLong("created_user_id"));
		cost.setCreated_dttm(rs.getTimestamp("created_dttm"));
		cost.setUpdated_user_id(rs.getLong("updated_user_id"));
		cost.setUpdated_dttm(rs.getTimestamp("updated_dttm"));
		cost.setStatus(rs.getBoolean("status"));
		cost.setProject(CostProjectMap(rs));
		return cost;
	}

	/**
	 * @param rs
	 * @return List of {@link Project}
	 * @throws SQLException
	 */
	public Project CostProjectMap(ResultSet rs) throws SQLException {
			Project projectData = new Project(rs.getLong("project_Id"), rs.getString("project_Name"),
					rs.getLong("project_Description"), rs.getTimestamp("project_Start_Date"),
					rs.getTimestamp("project_End_Date"), rs.getTimestamp("project_Duration"),
					rs.getLong("created_User_Id"), rs.getTimestamp("created_dttm"), rs.getLong("updated_User_Id"),
					rs.getTimestamp("updated_dttm"), rs.getBoolean("status"));
			if (projectData.getProject_Id() > 0)
				return projectData;
			else
				return null;
	
	}

}
