package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.model.Customer;
import com.model.Project;


public class CustomerMapper implements RowMapper<Customer>{

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
	 */
	@Override
	public Customer mapRow(ResultSet rs, int rownum) throws SQLException {
		Customer customerData  = new Customer();
		customerData.setCustomer_id(rs.getLong("customer_id"));
		customerData.setCustomer_name(rs.getString("customer_name"));
		customerData.setCreated_user_id(rs.getLong("created_user_id"));
		customerData.setCreated_dttm(rs.getTimestamp("created_dttm"));
		customerData.setUpdated_user_id(rs.getLong("updated_user_id"));
		customerData.setUpdated_dttm(rs.getTimestamp("updated_dttm"));
		customerData.setStatus(rs.getBoolean("customer_status"));
		customerData.setProjectList(projectListMapper(rs));
		return  customerData;
	}

	/**
	 * @param ResultSet rs
	 * @return list of {@link Project} objects
	 * @throws SQLException
	 */
	public List<Project> projectListMapper(ResultSet rs) throws SQLException{

		try {
			List<Project> projectList = new ArrayList<Project>();
			do{
				Project projectData = new Project(
						rs.getLong("project_id"), rs.getString("project_Name"),
						rs.getLong("project_Description"),rs.getTimestamp("project_Start_Date"),
						rs.getTimestamp("project_End_Date"), rs.getTimestamp("project_Duration"),
						rs.getLong("created_User_Id"), rs.getTimestamp("created_dttm"),
						rs.getLong("updated_User_id"), rs.getTimestamp("updated_dttm"),
						rs.getBoolean("status"));
				if(projectData.getProject_Id()!=0)
					projectList.add(projectData);
			}while(rs.next());

			return projectList;
		} catch (Exception e) {
			return null;
		}
	}

}
