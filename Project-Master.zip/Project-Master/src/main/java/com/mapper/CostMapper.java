package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.Cost;

public class CostMapper implements RowMapper<Cost> {

	public CostMapper() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Cost mapRow(ResultSet rs, int rownum) throws SQLException {
		Cost cst = new Cost();

		cst.setCost_master_id(rs.getLong("cost_master_id"));
		cst.setProject_id(rs.getLong("project_id"));
		cst.setLocation_id(rs.getLong("location_id"));
		cst.setCreated_user_id(rs.getLong("created_user_id"));
		cst.setCreated_dttm(rs.getTimestamp("created_dttm"));
		cst.setUpdated_user_id(rs.getLong("updated_user_id"));
		cst.setUpdated_dttm(rs.getTimestamp("updated_dttm"));
		cst.setStatus(rs.getBoolean("status"));
		return cst;
	}

}
