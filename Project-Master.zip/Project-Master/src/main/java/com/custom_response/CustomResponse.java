package com.custom_response;

public class CustomResponse {

	private int HttpStatus;
	private String message;
	
	
	public int getStatus() {
		return HttpStatus;
	}
	public void setStatus(int status) {
		HttpStatus = status;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public CustomResponse(int status, String message) {
		super();
		HttpStatus = status;
		this.message = message;
		
	}
	public CustomResponse() {
		super();
	}
	
	
	
	
	
}
