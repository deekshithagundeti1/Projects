package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.custom_response.CustomResponse;
import com.model.Customer;
import com.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService;

	/**
	 * @param customer
	 * @return {@link ResponseEntity, CustomResponse}
	 */
	@PostMapping(path = "/addCustomer")
	public ResponseEntity<CustomResponse> addCustomer(@RequestBody Customer NewCustomer) {
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.CREATED.value(),
				customerService.addCustomer(NewCustomer) + " :Customer successfully created"),HttpStatus.CREATED);
	}

	/**
	 * @param id
	 * @return {@link ResponseEntity, Customer}
	 */
	@GetMapping(path = "/getCustomerById/{customer_id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable("customer_id") Long customer_id) {
		return new ResponseEntity<Customer>(customerService.getCustomerById(customer_id), 
				HttpStatus.OK);
	}

	/**
	 * @return List of {@link Customer}
	 */
	@GetMapping(path = "/getAllCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers() {
		return new ResponseEntity<List<Customer>>(customerService.getAllCustomers(), HttpStatus.OK);
	}

	/**
	 * @return list of active {@link Customer}
	 */
	@GetMapping(path = "/getActiveCustomers")
	public ResponseEntity<List<Customer>> getAllActiveCustomers() {
		return new ResponseEntity<List<Customer>>(customerService.getAllActiveCustomers(), 
				HttpStatus.OK);

	}

	/**
	 * @param customerId
	 * @return {@link CustomResponse}
	 */
	@DeleteMapping(path = "/deleteCustomerById/{customerId}")
	public ResponseEntity<CustomResponse> deleteCustomerById(@PathVariable("customerId") Long customerId) {
		
		customerService.deleteCustomerById(customerId);
		
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value() , 
					"Customer successfully deleted"),HttpStatus.OK);
	}

	/**
	 * @param customer
	 * @return {@link CustomResponse}
	 */
	@RequestMapping(path = "/updateCustomer")
	public ResponseEntity<CustomResponse> updateCustomer(@RequestBody Customer updatedCustomer) {
		
		customerService.updateCustomer(updatedCustomer);
		
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(), 
				"Customer Updated"),HttpStatus.OK);
	}

	/**
	 * @param id
	 * @return {@link CustomResponse}
	 */
	@PutMapping(path = "/activateCustomerById/{customerId}")
	public ResponseEntity<CustomResponse> activateCustomerById(@PathVariable("customerId") Long customerId) {
		
		customerService.activateCustomerById(customerId);
		
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(),
			customerId + ": customer successfully activated"),HttpStatus.OK);
	}
	
	/**
	 * @param customerId
	 * @return
	 */
	@PutMapping(path = "/deactivateCustomerById/{customerId}")
	public ResponseEntity<CustomResponse> deactivateCustomerById(@PathVariable("customerId") Long customerId) {
		
		customerService.deactivateCustomerById(customerId);
		
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(),
			customerId + ": customer successfully deactivated"),HttpStatus.OK);
	}

}
