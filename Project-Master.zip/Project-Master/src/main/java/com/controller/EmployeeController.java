package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.custom_response.CustomResponse;
import com.model.Employee;
import com.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	/**
	 * @param em
	 * @return 
	 */
	@PostMapping(path = "/addEmployee")
	public ResponseEntity<CustomResponse> addEmployee(@RequestBody Employee newEmployee) {

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.CREATED.value(),
				"Employee ID :"+employeeService.addEmployee(newEmployee)), HttpStatus.CREATED);
	}


	/**
	 * @param Employee_id
	 * @return {@link Employee}
	 */
	@GetMapping(path = "/getEmployeeById/{Employee_id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable("Employee_id") Long Employee_id) {

		return new ResponseEntity<Employee>(employeeService.getEmployeeById(Employee_id), HttpStatus.OK);
	}


	/**
	 * @return List of {@link Employee}
	 */
	@GetMapping(path = "/getAllEmployee")
	public ResponseEntity<List<Employee>> getAllEmployee() {
		return new ResponseEntity<List<Employee>>(employeeService.getAllEmployee(), new HttpHeaders(), HttpStatus.OK);
	}

	/**
	 * @param Employee_id
	 * @return integer value
	 */
	@DeleteMapping(path = "/deleteEmployee/{Employee_id}")
	public ResponseEntity<CustomResponse> deleteEmployee(@PathVariable("Employee_id") Long Employee_id) {

		employeeService.deleteEmployee(Employee_id);

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(),
				"Employee successfully deleted"),HttpStatus.OK);
	}


	/**
	 * @param employee
	 * @return
	 */
	@PutMapping(path = "/UpdateEmployee")
	public ResponseEntity<CustomResponse> updateEmployee(@RequestBody Employee employee) {

		employeeService.UpdateEmployee(employee);

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.CREATED.value(),
				"Employee successfully updated"), HttpStatus.CREATED);
	}


	/**
	 * @return List of {@link Employee}
	 */
	@GetMapping(path = "/getActiveEmployee")
	public ResponseEntity<List<Employee>> getActiveEmployee() {
		return new ResponseEntity<List<Employee>>(employeeService.getActiveEmployee(), HttpStatus.OK);
	}


	@PutMapping(path="/activateEmployee/{employee_Id}")
	public ResponseEntity<CustomResponse> activateEmployee(@PathVariable("employee_Id")Long employee_Id){

		employeeService.activateEmployee(employee_Id);

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(), 
				"Employee successfully activated"), HttpStatus.OK);
	}


	@PutMapping(path="/deactivateEmployee/{employee_Id}")
	public ResponseEntity<CustomResponse> deactivateEmployee(@PathVariable("employee_Id")Long employee_Id){

		employeeService.deactivateEmployee(employee_Id);

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(), 
				"Employee successfully deactivated"), HttpStatus.OK);
	}




}
