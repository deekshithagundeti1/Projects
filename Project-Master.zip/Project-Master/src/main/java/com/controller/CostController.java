package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.custom_response.CustomResponse;
import com.model.Cost;
import com.service.CostService;
import com.service.ProjectService;


@RestController
public class CostController {

	@Autowired
	CostService costService;

	@Autowired
	ProjectService projectService;


	/**
	 * Add item by Id
	 * 
	 * @param costData
	 * 
	 * @return Cost
	 */
	@PostMapping(path = "/addCost")
	public ResponseEntity<CustomResponse> addCost(@RequestBody Cost costData) {

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.CREATED.value(),
				"Cost Added with unique id " + costService.addCost(costData)),HttpStatus.CREATED);

	}



	/**
	 * @param id
	 * @return 
	 */
	@GetMapping(path = "/getCostById/{cost_id}") 
	public ResponseEntity<Cost>getCostById(@PathVariable("cost_id") Long cost_id) { 

		return new ResponseEntity<Cost>(costService.getCostById(cost_id), HttpStatus.OK); 

	}

	/**
	 * Fetching all Items
	 * 
	 * @return list
	 */
	@GetMapping(path="/getCostForAllProjects")
	public ResponseEntity<List<Cost>> getAllItems() {
		return new ResponseEntity<List<Cost>>(costService.getCostForAllProjects(), HttpStatus.OK);
	}



	/**
	 * Activating cost by ID
	 * 
	 * @param id
	 * 
	 * @return Cost
	 */
	@PutMapping(path = "/activateCost/{cost_id}")
	public ResponseEntity<CustomResponse> activateCost(@PathVariable("cost_id") Long cost_id) {
		
		costService.activateCost(cost_id);
		
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(), 
				"Cost activated with id " + cost_id), HttpStatus.OK);
	}


	/**
	 * @param cost_id
	 * @return {@link CustomResponse}
	 */
	@PutMapping(path = "/deactivateCost/{cost_id}")
	public ResponseEntity<CustomResponse> deactivateCost(@PathVariable("cost_id") Long cost_id) {
		
		costService.deactivateCost(cost_id);
		
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(), 
				"Cost deactivated with id " + cost_id), HttpStatus.OK);
	}


	/**
	 * @param cost_master_id
	 * @return {@link CustomResponse}
	 */
	@DeleteMapping(path = "/deleteItem/{cost_master_id}")
	public ResponseEntity<CustomResponse> deleteCost(@PathVariable("cost_master_id") long cost_master_id) {
		
		costService.deleteCost(cost_master_id);
		
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(),
				"Cost successfully deleted"), HttpStatus.OK);
	}

	/**
	 * Updating Item by ID
	 * 
	 * @param cm
	 * 
	 * @return Cost
	 */
	@PutMapping(path = "/updateCost")
	public ResponseEntity<CustomResponse> updateCost(@RequestBody Cost costData) {
		
		costService.updateCost(costData);
		
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.CREATED.value(),
				"cost successfully updated"),HttpStatus.CREATED);
	}


	/**
	 * @param Customer
	 * @return String
	 */
	public String checkCostAttributes(Cost newCost){
		String result = "";
		if(newCost.getProject_id()<0)
			result+= " ,Project_id";
		if(newCost.getCreated_user_id()==0)
			result+= " ,Created User Id";
		if(newCost.getCreated_dttm()==null)
			result+= " ,Created user timestamp";

		return (result.equals(""))? null:result.substring(2);
	}

}
