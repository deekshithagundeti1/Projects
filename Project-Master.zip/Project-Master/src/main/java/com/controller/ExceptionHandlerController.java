package com.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.custom_response.CustomResponse;
import com.exception_handler.EntityNotFoundException;
import com.exception_handler.InvalidAttributes;

@ControllerAdvice
public class ExceptionHandlerController {
		
	/**
	 * @param exec
	 * @return {@link CustomResponse}
	 */
	@ExceptionHandler(value  = InvalidAttributes.class)
	public ResponseEntity<CustomResponse> InvalidAttributesException(InvalidAttributes message){
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.UNPROCESSABLE_ENTITY.value(), 
				message.getMessage()), HttpStatus.UNPROCESSABLE_ENTITY);
	}
	
	/**
	 * @param message
	 * @return {@link CustomResponse}
	 */
	@ExceptionHandler(value = EntityNotFoundException.class)
	public ResponseEntity<CustomResponse> NotFoundException(EntityNotFoundException message){
		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.NOT_FOUND.value(), 
				message.getMessage()), HttpStatus.NOT_FOUND);
	}


}
