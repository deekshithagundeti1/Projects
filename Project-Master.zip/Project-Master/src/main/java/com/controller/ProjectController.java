package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.custom_response.CustomResponse;
import com.model.Project;
import com.service.ProjectService;

@RestController
public class ProjectController {

	@Autowired
	private ProjectService projectService;


	/**
	 * @param projectData
	 * @param customerName
	 * @return CustomResponse Object
	 */
	@RequestMapping("/addProject")
	public ResponseEntity<CustomResponse> addProject(@RequestBody Project projectData) {

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.CREATED.value(), 
				"Project Id :" + projectService.addProject(projectData)), HttpStatus.CREATED);
	}



	/**
	 * @param id
	 * @return {@link Project}
	 */
	@RequestMapping("/getProjectById/{project_id}")
	public ResponseEntity<Project> getProjectById(@PathVariable("project_id") long project_id) {

		return new ResponseEntity<Project>(projectService.getProjectById(project_id), HttpStatus.OK);
	}


	/**
	 * @return list of {@link Project}
	 */
	@RequestMapping("/projectList")
	public ResponseEntity<List<Project>> getAllProjects() {
		return new ResponseEntity<List<Project>>(projectService.getProjectList(), HttpStatus.OK);
	}


	/**
	 * @param projectData
	 * @return {@link CustomResponse}
	 */
	@RequestMapping("/updateProject")
	public ResponseEntity<CustomResponse> updateProject(@RequestBody Project projectData) {projectService.updateProject(projectData);

	return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(), 
			"project successfully updated"), HttpStatus.OK);

	}

	/**
	 * @param project_Id
	 * @return {@link CustomResponse}
	 */
	@RequestMapping("/deleteProjectById/{id}")
	public ResponseEntity<CustomResponse> deleteProject(@PathVariable("id") long project_Id) {
		projectService.deleteProject(project_Id);

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(),
				"project successfully deleted"), HttpStatus.OK);

	}

	/**
	 * @param id
	 * @return {@link CustomResponse}
	 */
	@RequestMapping("/deactivateProjectById/{id}")
	public ResponseEntity<CustomResponse> deactivateProject(@PathVariable("id") Long id) {
		projectService.deactivateProject(id);

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(), 
				"project successfully deactivated"), HttpStatus.OK);

	}

	/**
	 * @param id
	 * @return {@link CustomResponse}
	 */
	@RequestMapping("/activateProjectById/{id}")
	public ResponseEntity<CustomResponse> activateProject(@PathVariable("id") Long id) {
		projectService.activateProject(id);

		return new ResponseEntity<CustomResponse>(new CustomResponse(HttpStatus.OK.value(),
				"project successfully activated"), HttpStatus.OK);
	}
}
