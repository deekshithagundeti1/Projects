package com.model;

import java.sql.Timestamp;

public class Cost {
	
	
	/*variables declaration*/
	private long cost_master_id;
	private long project_id;
	private long location_id;
	private long created_user_id;
	private Timestamp created_dttm;
	private long updated_user_id;
	private Timestamp updated_dttm;
	private boolean status;
	public Project project;
	
	
	/*getters and setters*/
	public long getCost_master_id() {
		return cost_master_id;
	}
	public void setCost_master_id(long cost_master_id) {
		this.cost_master_id = cost_master_id;
	}
	public long getProject_id() {
		return project_id;
	}
	public void setProject_id(long project_id) {
		this.project_id = project_id;
	}
	public long getLocation_id() {
		return location_id;
	}
	public void setLocation_id(long location_id) {
		this.location_id = location_id;
	}
	public long getCreated_user_id() {
		return created_user_id;
	}
	public void setCreated_user_id(long created_user_id) {
		this.created_user_id = created_user_id;
	}
	public Timestamp getCreated_dttm() {
		return created_dttm;
	}
	public void setCreated_dttm(Timestamp created_dttm) {
		this.created_dttm = created_dttm;
	}
	public long getUpdated_user_id() {
		return updated_user_id;
	}
	public void setUpdated_user_id(long updated_user_id) {
		this.updated_user_id = updated_user_id;
	}
	public Timestamp getUpdated_dttm() {
		return updated_dttm;
	}
	public void setUpdated_dttm(Timestamp updated_dttm) {
		this.updated_dttm = updated_dttm;
	}
	public boolean getStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}


	public Cost() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Project getProject() {
		return project;
	}
	public void setProject(Project project) {
		this.project = project;
	}
	@Override
	public String toString() {
		return "Cost [cost_master_id=" + cost_master_id + ", project_id=" + project_id + ", location_id=" + location_id
				+ ", created_user_id=" + created_user_id + ", created_dttm=" + created_dttm + ", updated_user_id="
				+ updated_user_id + ", updated_dttm=" + updated_dttm + ", status=" + status + ", project=" + project
				+ "]";
	}
	public Cost(long cost_master_id, long project_id, long location_id, long created_user_id, Timestamp created_dttm,
			long updated_user_id, Timestamp updated_dttm, boolean status, Project project) {
		super();
		this.cost_master_id = cost_master_id;
		this.project_id = project_id;
		this.location_id = location_id;
		this.created_user_id = created_user_id;
		this.created_dttm = created_dttm;
		this.updated_user_id = updated_user_id;
		this.updated_dttm = updated_dttm;
		this.status = status;
		this.project = project;
	}
	
	public Cost(long cost_master_id, long project_id, long location_id, long created_user_id, Timestamp created_dttm,
			long updated_user_id, Timestamp updated_dttm, boolean status) {
		super();
		this.cost_master_id = cost_master_id;
		this.project_id = project_id;
		this.location_id = location_id;
		this.created_user_id = created_user_id;
		this.created_dttm = created_dttm;
		this.updated_user_id = updated_user_id;
		this.updated_dttm = updated_dttm;
		this.status = status;
	}


}