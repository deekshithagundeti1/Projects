package com.model;

import java.sql.Timestamp;
import java.util.List;

public class Customer {
	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", customer_name=" + customer_name + ", created_user_id="
				+ created_user_id + ", created_dttm=" + created_dttm + ", updated_user_id=" + updated_user_id
				+ ", updated_dttm=" + updated_dttm + ", status=" + status + ", projectList=" + projectList + "]";
	}

	/* Variables declaration */
	private long customer_id;
	private String customer_name;
	private long created_user_id;
	private Timestamp created_dttm;
	private long updated_user_id;
	private Timestamp updated_dttm;
	private boolean status;
	private List<Project> projectList;

	public List<Project> getProjectList() {
		return projectList;
	}

	public void setProjectList(List<Project> projectList) {
		this.projectList = projectList;
	}

	/* Constructors declaration */
	public Customer() {
	}

	

	public Customer(long customer_id, String customer_name, long created_user_id, Timestamp created_dttm,
			long updated_user_id, Timestamp updated_dttm, boolean status, List<Project> projectList) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.created_user_id = created_user_id;
		this.created_dttm = created_dttm;
		this.updated_user_id = updated_user_id;
		this.updated_dttm = updated_dttm;
		this.status = status;
		this.projectList = projectList;
	}
	
	public Customer(long customer_id, String customer_name, long created_user_id, Timestamp created_dttm,
			long updated_user_id, Timestamp updated_dttm, boolean status) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.created_user_id = created_user_id;
		this.created_dttm = created_dttm;
		this.updated_user_id = updated_user_id;
		this.updated_dttm = updated_dttm;
		this.status = status;
	}

	/* Getters and Setters declaration */
	public long getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public long getCreated_user_id() {
		return created_user_id;
	}

	public void setCreated_user_id(long created_user_id) {
		this.created_user_id = created_user_id;
	}

	public Timestamp getCreated_dttm() {
		return created_dttm;
	}

	public void setCreated_dttm(Timestamp created_dttm) {
		this.created_dttm = created_dttm;
	}

	public long getUpdated_user_id() {
		return updated_user_id;
	}

	public void setUpdated_user_id(long updated_user_id) {
		this.updated_user_id = updated_user_id;
	}

	public Timestamp getUpdated_dttm() {
		return updated_dttm;
	}

	public void setUpdated_dttm(Timestamp updated_dttm) {
		this.updated_dttm = updated_dttm;
	}

	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

}
