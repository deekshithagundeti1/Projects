package com.model;

import java.sql.Timestamp;
import java.util.List;

/**
 * @author 768851
 *
 */
public class Project {

	private Long project_Id;


	private String project_Name;
	private Long project_Description;
	private Timestamp project_Start_Date;
	private Timestamp project_End_Date;
	private Timestamp project_Duration;
	private Long created_User_Id;
	private Timestamp created_Date_Time;
	private Long updated_User_id;
	private Timestamp updated_Date_Time;
	private Boolean status;
	private List<Employee> employee;



	/**
	 * @param status
	 */
	public void setStatus(Boolean status) {
		this.status = status;
	}

	/**
	 * @return true or false
	 */
	public Boolean getStatus() {
		return status;
	}

	/**
	 * @param status
	 */
	public void setStatus(boolean status) {
		this.status = status;
	}

	/**
	 * @return long project id
	 */
	public Long getProject_Id() {
		return project_Id;
	}



	/**
	 * @param project_Id
	 */
	public void setProject_Id(Long project_Id) {
		this.project_Id = project_Id;
	}



	/**
	 * @return String
	 */
	public String getProject_Name() {
		return project_Name;
	}



	/**
	 * @param project_Name
	 */
	public void setProject_Name(String project_Name) {
		this.project_Name = project_Name;
	}



	/**
	 * @return long id
	 */
	public Long getProject_Description() {
		return project_Description;
	}



	/**
	 * @param project_Description
	 */
	public void setProject_Description(Long project_Description) {
		this.project_Description = project_Description;
	}



	/**
	 * @return Time stamp
	 */
	public Timestamp getProject_Start_Date() {
		return project_Start_Date;
	}



	/**
	 * @param project_Start_Date
	 */
	public void setProject_Start_Date(Timestamp project_Start_Date) {
		this.project_Start_Date = project_Start_Date;
	}



	/**
	 * @return Timestamp
	 */
	public Timestamp getProject_End_Date() {
		return project_End_Date;
	}


	/**
	 * @param project_End_Date
	 */
	public void setProject_End_Date(Timestamp project_End_Date) {
		this.project_End_Date = project_End_Date;
	}


	/**
	 * @return Time stamp 
	 */
	public Timestamp getProject_Duration() {
		return project_Duration;
	}


	/**
	 * @param project_Duration
	 */
	public void setProject_Duration(Timestamp project_Duration) {
		this.project_Duration = project_Duration;
	}


	/**
	 * @return long id
	 */
	public Long getCreated_User_Id() {
		return created_User_Id;
	}



	/**
	 * @param created_User_Id
	 */
	public void setCreated_User_Id(Long created_User_Id) {
		this.created_User_Id = created_User_Id;
	}



	/**
	 * @return timestamp
	 */
	public Timestamp getCreated_Date_Time() {
		return created_Date_Time;
	}


	/**
	 * @param created_Date_Time
	 */
	public void setCreated_Date_Time(Timestamp created_Date_Time) {
		this.created_Date_Time = created_Date_Time;
	}


	/**
	 * @return long
	 */
	public Long getUpdated_User_id() {
		return updated_User_id;
	}


	/**
	 * @param updated_User_id
	 */
	public void setUpdated_User_id(Long updated_User_id) {
		this.updated_User_id = updated_User_id;
	}


	/**
	 * @return timestamp
	 */
	public Timestamp getUpdated_Date_Time() {
		return updated_Date_Time;
	}

	/**
	 * @param updated_Date_Time
	 */
	public void setUpdated_Date_Time(Timestamp updated_Date_Time) {
		this.updated_Date_Time = updated_Date_Time;
	}
	
	/**
	 * @return Employees list
	 */

	public List<Employee> getEmployee() {
		return employee;
	}

	/**
	 * @param Employee object 
	 */
	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}

	/**
	 * @param project_Id
	 * @param project_Name
	 * @param project_Description
	 * @param project_Start_Date
	 * @param project_End_Date
	 * @param project_Duration
	 * @param created_User_Id
	 * @param created_Date_Time
	 * @param updated_User_id
	 * @param updated_Date_Time
	 * @param status
	 */
	public Project(Long project_Id, String project_Name, Long project_Description,
			Timestamp project_Start_Date, Timestamp project_End_Date, Timestamp project_Duration, Long created_User_Id,
			Timestamp created_Date_Time, Long updated_User_id, Timestamp updated_Date_Time, Boolean status) {
		super();
		this.project_Id = project_Id;
		this.project_Name = project_Name;
		this.project_Description = project_Description;
		this.project_Start_Date = project_Start_Date;
		this.project_End_Date = project_End_Date;
		this.project_Duration = project_Duration;
		this.created_User_Id = created_User_Id;
		this.created_Date_Time = created_Date_Time;
		this.updated_User_id = updated_User_id;
		this.updated_Date_Time = updated_Date_Time;
		this.status = status;
	}
	/**
	 * @param project_Id
	 * @param project_Name
	 * @param project_Description
	 * @param project_Start_Date
	 * @param project_End_Date
	 * @param project_Duration
	 * @param created_User_Id
	 * @param created_Date_Time
	 * @param updated_User_id
	 * @param updated_Date_Time
	 * @param status
	 * @param employee
	 */

	public Project(Long project_Id, String project_Name, Long project_Description, Timestamp project_Start_Date,
			Timestamp project_End_Date, Timestamp project_Duration, Long created_User_Id, Timestamp created_Date_Time,
			Long updated_User_id, Timestamp updated_Date_Time, Boolean status, List<Employee> employee) {
		super();
		this.project_Id = project_Id;
		this.project_Name = project_Name;
		this.project_Description = project_Description;
		this.project_Start_Date = project_Start_Date;
		this.project_End_Date = project_End_Date;
		this.project_Duration = project_Duration;
		this.created_User_Id = created_User_Id;
		this.created_Date_Time = created_Date_Time;
		this.updated_User_id = updated_User_id;
		this.updated_Date_Time = updated_Date_Time;
		this.status = status;
		this.employee = employee;
	}

	
	public Project() {
		super();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Project [project_Id=" + project_Id + ", project_Name=" + project_Name
				+ ", project_Description=" + project_Description + ", project_Start_Date=" + project_Start_Date
				+ ", project_End_Date=" + project_End_Date + ", project_Duration=" + project_Duration
				+ ", created_User_Id=" + created_User_Id + ", created_Date_Time=" + created_Date_Time
				+ ", updated_User_id=" + updated_User_id + ", updated_Date_Time=" + updated_Date_Time + ", status="
				+ status + "]";
	}




}
