package com.model;

import java.sql.Timestamp;

public class Employee {

	private long employee_id;
	private String employee_name;
	private long created_user_id;
	private Timestamp created_dttm;
	private long updated_user_id;
	private Timestamp updated_dttm;
	private long project_id;
	private boolean status;

	/**
	 * 
	 * @return status
	 */

	public boolean getStatus() {
		return status;
	}

	/**
	 * 
	 * @param status
	 */
	public void setStatus(boolean status) {
		this.status = status;
	}

	/**
	 * 
	 * @return employee_id
	 */
	public long getEmployee_id() {
		return employee_id;
	}

	/**
	 * super class for Employee
	 */
	public Employee() {
		super();
	}

	/**
	 * Constructor class of Employee with the parameters
	 * 
	 * @param employee_id
	 * @param employee_name
	 * @param created_user_id
	 * @param created_dttm
	 * @param updated_user_id
	 * @param updated_dttm
	 * @param project_id
	 * @param status
	 */
	public Employee(long employee_id, String employee_name, long created_user_id, Timestamp created_dttm,
			long updated_user_id, Timestamp updated_dttm, long project_id, boolean status) {
		super();
		this.employee_id = employee_id;
		this.employee_name = employee_name;
		this.created_user_id = created_user_id;
		this.created_dttm = created_dttm;
		this.updated_user_id = updated_user_id;
		this.updated_dttm = updated_dttm;
		this.project_id = project_id;
		this.status = status;
	}

	/**
	 * 
	 * @param employee_id
	 */
	public void setEmployee_id(long employee_id) {
		this.employee_id = employee_id;
	}

	/**
	 * 
	 * @return string
	 */
	public String getEmployee_name() {
		return employee_name;
	}

	/**
	 * 
	 * @param employee_name
	 */
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	/**
	 * 
	 * @return created_uer_id long
	 */
	public long getCreated_user_id() {
		return created_user_id;
	}

	/**
	 * 
	 * @param created_user_id
	 *            long
	 */
	public void setCreated_user_id(long created_user_id) {
		this.created_user_id = created_user_id;
	}

	/**
	 * 
	 * @return created_date_time timestamp
	 */
	public Timestamp getCreated_dttm() {
		return created_dttm;
	}

	/**
	 * 
	 * @param created_dttm
	 */
	public void setCreated_dttm(Timestamp created_dttm) {
		this.created_dttm = created_dttm;
	}

	/**
	 * 
	 * @return updated_user_id long
	 */
	public long getUpdated_user_id() {
		return updated_user_id;
	}

	/**
	 * 
	 * @param updated_user_id
	 */
	public void setUpdated_user_id(long updated_user_id) {
		this.updated_user_id = updated_user_id;
	}

	/**
	 * 
	 * @return updated_date_time timestamp
	 */
	public Timestamp getUpdated_dttm() {
		return updated_dttm;
	}

	/**
	 * 
	 * @param updated_dttm
	 */
	public void setUpdated_dttm(Timestamp updated_dttm) {
		this.updated_dttm = updated_dttm;
	}

	/**
	 * 
	 * @return project_id long
	 */
	public long getProject_id() {
		return project_id;
	}

	/**
	 * 
	 * @param project_id
	 */
	public void setProject_id(long project_id) {
		this.project_id = project_id;
	}

	@Override
	public String toString() {
		return "Employee [employee_id=" + employee_id + ", employee_name=" + employee_name + ", created_user_id="
				+ created_user_id + ", created_dttm=" + created_dttm + ", updated_user_id=" + updated_user_id
				+ ", updated_dttm=" + updated_dttm + ", project_id=" + project_id + ", status=" + status + "]";
	}

}
