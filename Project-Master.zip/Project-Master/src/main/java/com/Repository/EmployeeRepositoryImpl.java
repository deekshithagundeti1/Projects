package com.Repository;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.mapper.EmployeeMapper;
import com.model.Employee;

@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {


	@Autowired
	JdbcTemplate template;

	KeyHolder key = new GeneratedKeyHolder();
	/**
	 * 
	 * @param beanId
	 * @return beanObject
	 */
	@SuppressWarnings("resource")
	private Object getBeanFromFactory(String beanId) {

		Object obj = null;
		ApplicationContext context = new FileSystemXmlApplicationContext("classpath*:/query-context.xml");
		if (context != null && beanId != null) {
			obj = context.getBean(beanId);
		}
		return obj;
	}

	/**
	 * 
	 * @param queryId
	 * @return query
	 */
	@SuppressWarnings("rawtypes")
	private String getQueryById(String queryId) {
		Map queryMap = null;
		String query = null;
		queryMap = (Map) this.getBeanFromFactory("queries");
		query = (String) queryMap.get(queryId);
		return query;
	}



	/*
	 * (non-Javadoc)
	 * 
	 * @see com.Repository.EmployeeRepository#getAllEmployee()
	 */
	@Override
	public List<Employee> getAllEmployee() {
		try {
			return template.query(getQueryById("GET_ALL_EMPLOYEES"), new EmployeeMapper());
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.Repository.EmployeeRepository#getEmployee(long)
	 */

	@Override
	public Employee getEmployeeById(long Employee_id) {
		try {
			return template.queryForObject(getQueryById("GET_EMPLOYEE"), new Object[] { Employee_id },
					new EmployeeMapper());
		} catch (Exception e) {
			return null;
		}

	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see com.Repository.EmployeeRepository#addEmp(com.model.Employee)
	 */
	@Override
	public long addEmployee(Employee employee) {

		try {
			template.update((connection) -> {
				PreparedStatement ps = connection.prepareStatement(getQueryById("ADD_EMPLOYEE"), new String[] { "id" });
				ps.setObject(1, employee.getEmployee_name());
				ps.setObject(2, employee.getCreated_user_id());
				ps.setObject(3, employee.getCreated_dttm());
				ps.setObject(4, employee.getUpdated_user_id());
				ps.setObject(5, employee.getUpdated_dttm());
				ps.setObject(6, employee.getProject_id());
				return ps;

			}, key);
			return (long) key.getKey().longValue();
		} catch (Exception e) {
			return 0;
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.Repository.EmployeeRepository#deleteEmp(long)
	 */
	@Override
	public boolean deleteEmployee(long Employee_id) {
		try {
			return template.update(getQueryById("DELETE_EMPLOYEE"), Employee_id)>0;
		} catch (Exception e) {
			return false;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.Repository.EmployeeRepository#UpdateEmp(com.model.Employee)
	 */
	@Override
	public boolean UpdateEmployee(Employee employee) {
		try {
			return template.update(getQueryById("UPDATE_EMPLOYEE"), employee.getEmployee_name(), 
					employee.getCreated_user_id(), employee.getCreated_dttm(),
					employee.getUpdated_user_id(), employee.getUpdated_dttm(),
					employee.getStatus(), employee.getProject_id(), employee.getEmployee_id())>0;
		} catch (Exception e) {
			return false;
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.Repository.EmployeeRepository#ActEmp()
	 */
	@Override
	public List<Employee> getActiveEmployee() {
		try {
			return template.query(getQueryById("ACTIVE_EMPLOYEE"),new EmployeeMapper());
		} catch (Exception e) {
			return null;
		}
	}


	/* (non-Javadoc)
	 * @see com.Repository.EmployeeRepository#getEmployeeByNameAndProjectId(java.lang.String, java.lang.Long)
	 */
	@Override
	public Employee getEmployeeByNameAndProjectId(String employeeName, Long project_id) {
		try {
			return template.queryForObject(getQueryById("GET_EMPLOYEE_BY_NAME_AND_PROJECT_ID"),
					new Object[]{employeeName, project_id}, new EmployeeMapper());
		} catch (Exception e) {
			return null;
		}
	}


	/* (non-Javadoc)
	 * @see com.Repository.EmployeeRepository#activateEmployee(java.lang.Long)
	 */
	@Override
	public boolean activateEmployee(Long employee_Id) {
		try {
			return template.update(getQueryById("ACTIVATE_EMPLOYEE"), employee_Id)>0;
		} catch (Exception e) {
			return false;
		}
	}

	
	/* (non-Javadoc)
	 * @see com.Repository.EmployeeRepository#deactivateEmployee(java.lang.Long)
	 */
	@Override
	public boolean deactivateEmployee(Long employee_Id) {
		try {
			return template.update(getQueryById("DEACTIVATE_EMPLOYEE"), employee_Id)>0;
		} catch (Exception e) {
			return false;
		}
	}

}
