package com.Repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.model.Employee;

@Repository
public interface EmployeeRepository {

	/**
	 * Fetches the list of all Employee
	 * 
	 * @return the list
	 */
	public List<Employee> getAllEmployee();

	/**
	 * 
	 * @param Employee_id
	 * @return the particular employee details
	 */

	public Employee getEmployeeById(long Employee_id);

	/**
	 * 
	 * @param em
	 * @return added employee along with id if inserted
	 */

	public long addEmployee(Employee employee);

	/**
	 * 
	 * @param Employee_id
	 * @return the status
	 */

	public boolean deleteEmployee(long Employee_id);

	/**
	 * 
	 * @param em
	 */

	public boolean UpdateEmployee(Employee employee);

	/**
	 * 
	 * @return the list of active employee
	 */

	public List<Employee> getActiveEmployee();

	/**
	 * @param employeeName
	 * @param project_id
	 * @return {@link Employee}
	 */
	public Employee getEmployeeByNameAndProjectId(String employeeName, Long project_id);

	/**
	 * @param employee_Id
	 * @return boolean
	 */
	public boolean activateEmployee(Long employee_Id);

	/**
	 * @param employee_Id
	 * @return boolean
	 */
	public boolean deactivateEmployee(Long employee_Id);

}
