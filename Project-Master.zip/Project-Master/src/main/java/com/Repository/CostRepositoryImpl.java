package com.Repository;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.mapper.CostMapper;
import com.mapper.CostProjectMapper;
import com.model.Cost;

@Repository

public class CostRepositoryImpl implements CostRepository {

	@Autowired
	JdbcTemplate template;
	
	KeyHolder key = new GeneratedKeyHolder();
	
	
	
	/**
	 * @param beanId
	 * @return Object
	 */
	@SuppressWarnings("resource")
	private Object getBeanFromFactory(String beanId) {
		Object obj = null;
		ApplicationContext context = new FileSystemXmlApplicationContext("classpath*:/query-context.xml");
		if (context != null && beanId != null) {
			obj = context.getBean(beanId);
		}
		return obj;
	}

	
	
	/**
	 * @param queryId
	 * @return sql query
	 */
	@SuppressWarnings("rawtypes")
	private String getQueryById(String queryId) {
		Map queryMap = null;
		String query = null;
		queryMap = (Map) this.getBeanFromFactory("queries");
		query = (String) queryMap.get(queryId);
		return query;
	}



	/* (non-Javadoc)
	 * @see com.Repository.CostRepository#addCost(com.model.Cost)
	 */
	@Override
	public long addCost(Cost costData) {
		try {
			template.update((connection) -> {
				PreparedStatement ps = connection.prepareStatement(getQueryById("ADD_COST"), new String[] { "id" });
				ps.setObject(1, costData.getProject_id());
				ps.setObject(2, costData.getLocation_id());
				ps.setObject(3, costData.getCreated_user_id());
				ps.setObject(4, costData.getCreated_dttm());
				ps.setObject(5, costData.getUpdated_user_id());
				ps.setObject(6, costData.getUpdated_dttm());
				ps.setObject(7, costData.getStatus());
				return ps;

			}, key);
			return (long) key.getKey().longValue();
		} catch (Exception e) {
			return 0;
		}
	}



	/* (non-Javadoc)
	 * @see com.Repository.CostRepository#getCostById(long)
	 */
	@Override
	public Cost getCostById(long cost_master_id) {
		try {
			return template.queryForObject(getQueryById("GET_COST_BY_ID"), new Object[] { cost_master_id },
					new CostProjectMapper());
		} catch (Exception e) {
			return null;
		}
	}



	@Override
	public boolean updateCost(Cost costData) {
		try {
			return template.update(getQueryById("UPDATE_COST"), costData.getProject_id(),
					costData.getLocation_id(), costData.getCreated_user_id(),
					costData.getCreated_dttm(), costData.getUpdated_user_id(),
					costData.getUpdated_dttm(), costData.getStatus(),costData.getCost_master_id())>0;
		} catch (Exception e) {
			return false;
		}
	}



	@Override
	public List<Cost> getCostForAllProjects() {
		try {
			return template.query(getQueryById("GET_ALL_COST"), new CostProjectMapper());
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public boolean deleteCost(long Cost_master_id) {
		try {
			return template.update(getQueryById("DELETE_COST"), new Object[]{Cost_master_id})>0;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Cost getCostByProjectId(long project_id) {
		try {
			return template.queryForObject(getQueryById("GET_COST_BY_PROJECT"), 
					new Object[]{project_id},new CostMapper());
		} catch (Exception e) {
			return null;
		}
	}
	

	@Override
	public boolean activateCost(long cost_id) {
		try {
			return template.update(getQueryById("ACTIVATE_COST"), new Object[]{cost_id})>0;
		} catch (Exception e) {
			return false;
		}
	}



	@Override
	public boolean deactivateCost(long cost_id) {
		try {
			return template.update(getQueryById("DEACTIVATE_COST"), new Object[]{cost_id})>0;
		} catch (Exception e) {
			return false;
		}
	}

}