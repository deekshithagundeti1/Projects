
package com.Repository;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.mapper.CustomerMapper;
import com.model.Customer;


@Repository
public class CustomerRepositoryImpl implements CustomerRepository {

	@Autowired
	JdbcTemplate template;
	
	KeyHolder key = new GeneratedKeyHolder();

	/**
	 * @param beanId
	 * @return object
	 */
	@SuppressWarnings("resource")
	private Object getBeanFromFactory(String beanId) {
		Object obj = null;
		ApplicationContext context = new FileSystemXmlApplicationContext("classpath*:/query-context.xml");
		if (context != null && beanId != null) {
			obj = context.getBean(beanId);
		}
		return obj;
	}



	/**
	 * @param queryId
	 * @return query string
	 */
	@SuppressWarnings("rawtypes")
	private String getQueryById(String queryId) {
		Map queryMap = null;
		String query = null;
		queryMap = (Map) this.getBeanFromFactory("queries");
		query = (String) queryMap.get(queryId);
		return query;
	}


	

	/* (non-Javadoc)
	 * @see com.Repository.CustomerRepository#addCustomer(com.model.Customer)
	 */
	@Override
	public long addCustomer(Customer customer) {
		try {
			template.update((connection) -> {
				PreparedStatement ps = connection.prepareStatement(getQueryById("ADD_CUSTOMER"), new String[] { "id" });
				ps.setObject(1, customer.getCustomer_name());
				ps.setObject(2, customer.getCreated_user_id());
				ps.setObject(3, customer.getCreated_dttm());
				ps.setObject(4, customer.getUpdated_user_id());
				ps.setObject(5, customer.getUpdated_dttm());
				ps.setObject(6, customer.getStatus());

				return ps;

			}, key);
			return (long) key.getKey().longValue();
		} catch (Exception e) {
			return 0;
		}

	}


	/* (non-Javadoc)
	 * @see com.Repository.CustomerRepository#getCustomerById(java.lang.Long)
	 */
	@Override
	public Customer getCustomerById(Long customer_id) {
		try {
			return template.queryForObject(getQueryById("GET_CUSTOMER"), new Object[] { customer_id },
					new CustomerMapper());
		} catch (Exception e) {
			return null;
		}
		
	}

	/* (non-Javadoc)
	 * @see com.Repository.CustomerRepository#getAllCustomers()
	 */
	@Override
	public List<Customer> getAllCustomers() {
		try {
			return  template.query(getQueryById("GET_ALL_CUSTOMERS"), new CustomerMapper());
		} catch (Exception e) {
			return null;
		}
	}




	/* (non-Javadoc)
	 * @see com.Repository.CustomerRepository#getAllActiveCustomers()
	 */
	@Override
	public List<Customer> getAllActiveCustomers() {
		try {
			return template.query(getQueryById("GET_ACTIVE_CUSTOMER"), new CustomerMapper());
		} catch (Exception e) {
			return null;
		}
	}



	/* (non-Javadoc)
	 * @see com.Repository.CustomerRepository#deleteCustomerById(java.lang.Long)
	 */
	@Override
	public boolean deleteCustomerById(Long customer_id) {
		try {
			return template.update(getQueryById("DELETE_CUSTOMER_BY_ID"), customer_id)>0;
		} catch (Exception e) {
			return false;
		}
	}



	/* (non-Javadoc)
	 * @see com.Repository.CustomerRepository#updateCustomer(com.model.Customer)
	 */
	@Override
	public boolean updateCustomer(Customer customer) {
		try {
			Object[] args = new Object[] { customer.getCustomer_name(), customer.getCreated_user_id(),
					customer.getCreated_dttm(), customer.getUpdated_user_id(), customer.getUpdated_dttm(),
					customer.getStatus(),customer.getCustomer_id() };

			return template.update(getQueryById("UPDATE_CUSTOMER"), args)>0;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
	}



	/* (non-Javadoc)
	 * @see com.Repository.CustomerRepository#activateCustomerById(java.lang.Long)
	 */
	@Override
	public boolean activateCustomerById(Long customer_id) {
		try {
			return  template.update(getQueryById("ACTIVATE_CUSTOMER"), new Object[] { customer_id })>0;
		} catch (Exception e) {
			return false;
		}

	}


	/* (non-Javadoc)
	 * @see com.Repository.CustomerRepository#deactivateCustomerById(java.lang.Long)
	 */
	@Override
	public boolean deactivateCustomerById(Long customer_id) {
		try {
			return template.update(getQueryById("DEACTIVATE_CUSTOMER"), new Object[] { customer_id })>0;
		} catch (Exception e) {
			return false;
		}
	}



	/* (non-Javadoc)
	 * @see com.Repository.CustomerRepository#getCustomerByName(java.lang.String)
	 */
	@Override
	public Customer getCustomerByName(String customer_name) {
		try {
			return template.queryForObject(getQueryById("GET_CUSTOMER_BY_NAME"), new Object[] { customer_name }, new CustomerMapper());
		} catch (Exception e) {
			return null;
		}
		
	}


}
