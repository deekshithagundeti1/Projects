package com.Repository;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.mapper.ProjectEmployeeRowMapper;
import com.mapper.ProjectMapper;
import com.model.Project;

/**
 * @author 768851
 *
 */
@Repository
public class ProjectRepositoryImpl implements ProjectRepository {


	/**
	 * @param beanId
	 * @return bean object
	 */
	@SuppressWarnings("resource")
	private Object getBeanFromFactory(String beanId) {
		Object obj = null;
		ApplicationContext context = new FileSystemXmlApplicationContext("classpath*:/query-context.xml");
		if (context != null && beanId != null) {
			obj = context.getBean(beanId);
		}
		return obj;
	}


	/**
	 * @param queryId,
	 * @return String query 
	 */
	@SuppressWarnings("rawtypes")
	private String getQueryById(String queryId) {
		Map queryMap = null;
		String query = null;
		queryMap = (Map) this.getBeanFromFactory("queries");
		query = (String) queryMap.get(queryId);
		return query;
	}

	@Autowired
	JdbcTemplate jdbcTemplate;

	KeyHolder key = new GeneratedKeyHolder();



	/* (non-Javadoc)
	 * @see com.repository.RepositoryInterface#addProject(com.model.ProjectMasterModel, java.lang.String)
	 */
	@Override
	public long addProject(Project projectData, long project_id) {
		try {
			jdbcTemplate.update((connection) -> {
				PreparedStatement ps = connection.prepareStatement(getQueryById("ADD_PROJECT"), new String[] { "id" });
				ps.setObject(1, projectData.getProject_Name());
				ps.setObject(2, projectData.getProject_Description());
				ps.setObject(3, projectData.getProject_Start_Date());
				ps.setObject(4, projectData.getProject_End_Date());
				ps.setObject(5, projectData.getProject_Duration());
				ps.setObject(6, projectData.getCreated_Date_Time());
				ps.setObject(7, projectData.getUpdated_User_id());
				ps.setObject(8, projectData.getUpdated_Date_Time());
				ps.setObject(9, projectData.getStatus());
				ps.setObject(10, project_id);
				return ps;

			}, key);
			return (long) key.getKey().longValue();
		} catch (Exception e) {
			return 0;
		}
	}



	/* (non-Javadoc)
	 * @see com.repository.RepositoryInterface#getProjectList()
	 */
	@Override
	public List<Project> getProjectList() {
		try {
			return jdbcTemplate.query(getQueryById("GET_ALL_PROJECT"), new ProjectMapper());
		} catch (Exception e) {
			return null;
		}
	}



	/* (non-Javadoc)
	 * @see com.repository.RepositoryInterface#updateProject(com.model.ProjectMasterModel)
	 */
	@Override
	public boolean updateProject(Project projectData) {
		try {
			return jdbcTemplate.update(getQueryById("UPDATE_PROJECT"), projectData.getProject_Name(),
					projectData.getProject_Description(), projectData.getProject_Start_Date(),
					projectData.getProject_End_Date(), projectData.getProject_Duration(), projectData.getCreated_User_Id(),
					projectData.getCreated_Date_Time(), projectData.getUpdated_User_id(),
					projectData.getUpdated_Date_Time(), projectData.getProject_Id()) > 0;
		} catch (Exception e) {
			return false;
		}
	}



	/* (non-Javadoc)
	 * @see com.repository.RepositoryInterface#deleteProject(java.lang.Long)
	 */
	@Override
	public boolean deleteProject(Long project_id) {
		try {
			return jdbcTemplate.update(getQueryById("DELETE_PROJECT_BY_ID"), project_id) > 0;
		} catch (Exception e) {
			return false;
		}
	}


	/* (non-Javadoc)
	 * @see com.repository.RepositoryInterface#activateProject(java.lang.Long)
	 */
	@Override
	public boolean activateProject(Long project_id) {
		try {
			return jdbcTemplate.update(getQueryById("ACTIVATE_PROJECT"), project_id) > 0;
		} catch (Exception e) {
			return false;
		}
	}



	/* (non-Javadoc)
	 * @see com.repository.RepositoryInterface#deactivateProject(java.lang.Long)
	 */
	@Override
	public boolean deactivateProject(Long project_id) {
		try {
			return jdbcTemplate.update(getQueryById("DEACTIVATE_PROJECT"), project_id) > 0;
		} catch (Exception e) {
			return false;
		}
	}



	/* (non-Javadoc)
	 * @see com.repository.RepositoryInterface#getProjectStatus(java.lang.Long)
	 */
	@Override
	public boolean getProjectStatus(Long project_Id) {
		try {
			return jdbcTemplate.update(getQueryById("GET_PROJECT_STATUS"), project_Id) > 0;
		} catch (Exception e) {
			return false;
		}
	}



	/* (non-Javadoc)
	 * @see com.repository.RepositoryInterface#getProjectByName(java.lang.String, java.lang.String)
	 */
	@Override
	public Project getProjectByName(String projectName,Long customer_Id) {
		try {
			return jdbcTemplate.queryForObject(getQueryById("GET_PROJECT_BY_NAME"),
					new Object[] { projectName, customer_Id }, new ProjectMapper());
		} catch (Exception e) {
			return null;
		}
	}



	/* (non-Javadoc)
	 * @see com.repository.RepositoryInterface#getProjectById(long)
	 */
	@Override
	public Project getProjectById(long id) {
		try {
			return jdbcTemplate.queryForObject(getQueryById("GET_PROJECT_BY_ID"), new Object[] { id }, 
					new ProjectEmployeeRowMapper());
		} catch (Exception e) {
			return null;
		}
	}


	/* (non-Javadoc)
	 * @see com.Repository.ProjectRepository#getProjectEmp(java.lang.Long)
	 */
	@Override
	public Project getProjectEmp(Long id) {
		try {
			return jdbcTemplate.queryForObject(getQueryById("GET_PROJECT_WITH_EMP"), new Object[] { id }, new ProjectEmployeeRowMapper());
		} catch (Exception e) {
			return null;
		}
	}



	/* (non-Javadoc)
	 * @see com.Repository.ProjectRepository#getProjectByNameAndCustomerId(java.lang.String, long)
	 */
	@Override
	public Project getProjectByNameAndCustomerId(String project_Name, long customer_id) {
		try {
			return jdbcTemplate.queryForObject(getQueryById("GET_PROJECT_VIA_CUSTOMER"),
					new Object[]{project_Name,customer_id},new ProjectMapper());
		} catch (Exception e) {
			return null;
		}
	}

}
