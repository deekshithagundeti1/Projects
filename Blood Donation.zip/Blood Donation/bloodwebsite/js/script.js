( function( $ ) {
$( document ).ready(function() {
// Cache the elements we'll need
var menu = $('#cssmenu');
var menuList = menu.find('ul:first');
var listItems = menu.find('li').not('#responsive-tab');

// Create responsive trigger
menuList.prepend('<li id="responsive-tab"><a href="#">Menu</a></li>');

// Toggle menu visibility
menu.on('click', '#responsive-tab', function(){
	listItems.slideToggle('fast');
	listItems.addClass('collapsed');
});
});
} )( jQuery );

function slideSwitch() {
    var $active = $('#slideshow IMG.active');

    if ( $active.length == 0 ) $active = $('#slideshow IMG:last');

    // use this to pull the images in the order they appear in the markup
    var $next =  $active.next().length ? $active.next()
        : $('#slideshow IMG:first');

    // uncomment the 3 lines below to pull the images in random order
    
    // var $sibs  = $active.siblings();
    // var rndNum = Math.floor(Math.random() * $sibs.length );
    // var $next  = $( $sibs[ rndNum ] );


    $active.addClass('last-active');

    $next.css({opacity: 0.0})
        .addClass('active')
        .animate({opacity: 1.0}, 1000, function() {
            $active.removeClass('active last-active');
        });
}

$(function() {
    setInterval( "slideSwitch()", 5000 );
});

function openNav() {
    document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
    document.getElementById("myNav").style.width = "0%";
}
function openNav1() {
    document.getElementById("myNav1").style.width = "100%";
}

function closeNav1() {
    document.getElementById("myNav1").style.width = "0%";
}
function openNav2() {
    document.getElementById("myNav2").style.width = "100%";
}

function closeNav2() {
    document.getElementById("myNav2").style.width = "0%";
}
function val1()
{
var a=document.form1.emailid.value;
var b=document.form1.password.value;
var p=a.match(/[A-Za-z0-9\.*]+\@[A-Za-z0-9]+\.([A-Za-z]{2,3})([A-Za-z]?)/);
var q=b.match(/[A-Za-z0-9\.*]{8,}/);
if(!p)
alert("Not a valid email");
if(!q)
alert("enter valid password-should contain atleast one alphabet and integer");
}

function val2()
{
var a=document.form2.username.value;
var b=document.form2.emailid.value;
var c=document.form2.password.value;
var d=document.form2.phoneno.value;
var e=document.form2.age.value;
var f=document.form2.pincode.value;
var cp=document.form2.cpassword.value
var p=a.match(/[A-Za-z]+/);
var q=b.match(/[A-Za-z0-9\.*]+\@[A-Za-z0-9]+\.([A-Za-z]{2,3})/);
var r=c.match(/[A-Za-z0-9\.*]/);
var s=d.match(/[0-9]{10}/);
var t=e.match(/[0-9]+/);
var u=f.match(/[0-9]{6}/);
if(!p)
alert("Not a valid name");
if(!q)
alert("Not a valid email");
if(!r)
alert("enter valid password-should contain atleast one alphabet and integer and min 8 characters");
if(!s)
alert("enter a valid 10 digit number");
if(!t)
alert("enter your age in numbers");
if(!u)
alert("enter a valid 6 digit pincode");
if(c!=cp)
alert("passwords do not match");
if((c==cp)&&p&&q&&r&&s&&t&&u)
alert("registered successfully");
}
    function PassStrength(password) {
        var password_strength = document.getElementById("strength");
 
        //TextBox left blank.
        if (password.length == 0) {
            password_strength.innerHTML = "";
            return;
        }
 
        //Regular Expressions.
        var regex = new Array();
        regex.push("[A-Z]"); //Uppercase Alphabet.
        regex.push("[a-z]"); //Lowercase Alphabet.
        regex.push("[0-9]"); //Digit.
        regex.push("[$@$!%*#?&]"); //Special Character.
 
        var passed = 0;
 
        //Validate for each Regular Expression.
        for (var i = 0; i < regex.length; i++) {
            if (new RegExp(regex[i]).test(password)) {
                passed++;
            }
        }
 
        //Validate for length of Password.
        if (passed > 2 && password.length > 8) {
            passed++;
        }
 
        //Display status.
        var color = "";
        var strength = "";
        switch (passed) {
            case 0:
            case 1:
                strength = "Weak";
                color = "red";
                break;
            case 2:
                strength = "Good";
                color = "darkorange";
                break;
            case 3:
            case 4:
                strength = "Strong";
                color = "green";
                break;
            case 5:
                strength = "Very Strong";
                color = "darkgreen";
                break;
        }
        password_strength.innerHTML = strength;
        password_strength.style.color = color;
    }