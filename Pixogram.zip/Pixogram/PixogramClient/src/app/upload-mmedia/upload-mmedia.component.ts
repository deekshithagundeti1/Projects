import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-mmedia',
  templateUrl: './upload-mmedia.component.html',
  styleUrls: ['./upload-mmedia.component.css']
})
export class UploadMMediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
