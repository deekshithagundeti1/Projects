import {  OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MediaService } from '../media.service'
import { Media } from '../models/Media';

@Component({
  selector: 'app-upload-media',
  templateUrl: './upload-media.component.html',
  styleUrls: ['./upload-media.component.css']
})
export class UploadMediaComponent implements OnInit {

 
            public pic:Blob;
            public title:String;
            public description:String;
            public tags:String;
            public effects:String;


  constructor(private mediaService:MediaService,private router: Router) { }
 
  ngOnInit(): void {
  
  }
 
  onUpload() {
    let media = new Media(this.pic,this.title,this.description, this.tags,this.effects);
    this.mediaService.StoreFile(Media)
    .subscribe(data => console.log(data), error => console.log(error));

    this.router.navigate(['MyMedia']);
  }
}
