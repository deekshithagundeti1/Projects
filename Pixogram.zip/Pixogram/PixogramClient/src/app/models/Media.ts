
export class Media{
    constructor(

            public pic:Blob,
            public title:String,
            public description:String,
            public tags:String,
            public effects:String
        ) {
    }  
}