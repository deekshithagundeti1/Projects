import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-detail',
  templateUrl: './media-detail.component.html',
  styleUrls: ['./media-detail.component.css']
})
export class MediaDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
