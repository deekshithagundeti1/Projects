package com.sba.pixogram.repository;

import org.springframework.data.repository.CrudRepository;

import com.sba.pixogram.entity.Follow;

public interface FollowRepository extends CrudRepository<Follow, Long>{

}
