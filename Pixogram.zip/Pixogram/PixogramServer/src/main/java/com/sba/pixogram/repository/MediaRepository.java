package com.sba.pixogram.repository;

import org.springframework.data.repository.CrudRepository;

import com.sba.pixogram.entity.Media;

public interface MediaRepository extends CrudRepository<Media, Long> {

}
