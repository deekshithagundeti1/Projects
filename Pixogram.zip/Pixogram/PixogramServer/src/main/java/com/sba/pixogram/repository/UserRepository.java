package com.sba.pixogram.repository;

import org.springframework.data.repository.CrudRepository;

import com.sba.pixogram.entity.User;

public interface UserRepository extends CrudRepository<User, Long> {
}
